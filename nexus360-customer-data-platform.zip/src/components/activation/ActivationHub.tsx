import React, { useState } from 'react';
import { useCDP } from '../../context/CDPContext';
import { Destination, SyncExecutionLog } from '../../types/cdp';
import {
  Share2,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Pause,
  Play,
  Clock,
  Zap,
  ExternalLink,
  ArrowUpRight,
  Sliders,
  Sparkles
} from 'lucide-react';

export const ActivationHub: React.FC = () => {
  const {
    destinations,
    syncLogs,
    segments,
    triggerSync,
    syncAllAudiences,
    isSyncingGlobal,
    toggleDestinationStatus,
    updateDestinationFrequency
  } = useCDP();

  const [activeTab, setActiveTab] = useState<'destinations' | 'logs' | 'hasher'>('destinations');
  const [syncingDestId, setSyncingDestId] = useState<string | null>(null);

  // PII Hashing tester state
  const [hashInputEmail, setHashInputEmail] = useState('marcus.vance@vanguardhq.com');
  const [hashInputPhone, setHashInputPhone] = useState('+1 (415) 890-2134');

  // Simple pure JS sha-256 simulation or crypto subtle
  const [computedHash, setComputedHash] = useState('');

  React.useEffect(() => {
    // Generate deterministic sha-256 preview using web crypto
    async function digest(text: string) {
      if (!text.trim()) {
        setComputedHash('');
        return;
      }
      try {
        const msgUint8 = new TextEncoder().encode(text.trim().toLowerCase());
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        setComputedHash(hashHex);
      } catch {
        setComputedHash('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
      }
    }
    digest(hashInputEmail);
  }, [hashInputEmail]);

  const handleSyncDestination = async (destId: string) => {
    setSyncingDestId(destId);
    // Find segments mapped to this destination
    const targetSeg = segments.find(s => s.syncDestinations.includes(destId)) || segments[0];
    if (targetSeg) {
      await triggerSync(targetSeg.id, destId);
    }
    setSyncingDestId(null);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto">
      {/* Header */}
      <div className="p-6 border-b border-slate-800/80 bg-slate-900/40 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-base font-bold text-slate-100">Ad Platforms & Activation Hub</h1>
            <p className="text-xs text-slate-400">
              Synchronize dynamic audience segments with Google Ads, Meta, TikTok, and marketing clouds with SHA-256 hashing.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={syncAllAudiences}
              disabled={isSyncingGlobal}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap shadow-sm disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncingGlobal ? 'animate-spin' : ''}`} />
              <span>{isSyncingGlobal ? 'Pushing All Audiences...' : 'Trigger Global Push'}</span>
            </button>
          </div>
        </div>

        {/* Global Activation Benchmark KPI Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 font-mono block">CONNECTED PLATFORMS</span>
            <span className="text-base font-bold text-slate-100 font-mono tabular-nums">
              {destinations.filter(d => d.status === 'connected').length} / {destinations.length}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Active streaming connectors
            </span>
          </div>

          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 font-mono block">AVG MATCH RATE BENCHMARK</span>
            <span className="text-base font-bold text-cyan-400 font-mono tabular-nums">
              78.9%
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Across all ad channels
            </span>
          </div>

          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 font-mono block">PROFILES SYNCHRONIZED</span>
            <span className="text-base font-bold text-slate-100 font-mono tabular-nums">
              193,050
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Hashed PII payloads sent
            </span>
          </div>

          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded">
            <span className="text-[11px] text-slate-400 font-mono block">ENCRYPTION PROTOCOL</span>
            <div className="flex items-center gap-1 text-xs text-emerald-400 font-medium mt-1">
              <Lock className="w-3.5 h-3.5" />
              <span>SHA-256 One-Way</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Zero plaintext leak guarantee
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 px-6 border-b border-slate-800/80 bg-slate-950">
        <button
          onClick={() => setActiveTab('destinations')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'destinations'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Destinations & Connectors ({destinations.length})
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'logs'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Sync Execution Audit Logs ({syncLogs.length})
        </button>
        <button
          onClick={() => setActiveTab('hasher')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'hasher'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          SHA-256 Payload Inspector
        </button>
      </div>

      {/* Body Area */}
      <div className="p-6 flex-1">
        {activeTab === 'destinations' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {destinations.map(dest => {
              const isSyncing = syncingDestId === dest.id;

              return (
                <div
                  key={dest.id}
                  className="p-5 bg-slate-900/60 border border-slate-800 rounded-lg space-y-4 hover:border-slate-700 transition-colors flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    {/* Top Row */}
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-100">{dest.name}</span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono capitalize block mt-0.5">
                          {dest.category.replace('_', ' ')}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => toggleDestinationStatus(dest.id)}
                          title={dest.status === 'connected' ? 'Pause sync' : 'Resume sync'}
                          className={`p-1.5 rounded text-xs transition-colors border ${
                            dest.status === 'connected'
                              ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/80 hover:bg-emerald-900'
                              : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                          }`}
                        >
                          {dest.status === 'connected' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Stats metrics */}
                    <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-950 border border-slate-800/80 rounded font-mono text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">MATCH RATE</span>
                        <span className="text-emerald-400 font-bold tabular-nums">
                          {dest.matchRateBenchmark}%
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">PROFILES SYNCED</span>
                        <span className="text-slate-200 font-bold tabular-nums">
                          {dest.totalSyncedProfiles.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Cadence & Hashing details */}
                    <div className="space-y-1.5 text-xs text-slate-400">
                      <div className="flex items-center justify-between">
                        <span>Sync Cadence:</span>
                        <select
                          value={dest.syncFrequency}
                          onChange={e => updateDestinationFrequency(dest.id, e.target.value as any)}
                          className="bg-slate-950 border border-slate-800 rounded px-2 py-0.5 text-slate-200 text-xs font-mono"
                        >
                          <option value="realtime">Real-Time Streaming</option>
                          <option value="15m">Micro-Batch (15m)</option>
                          <option value="1h">Hourly Batch (1h)</option>
                          <option value="24h">Daily Sync (24h)</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Hashing Standard:</span>
                        <span className="text-slate-200 font-mono text-[11px]">{dest.hashingAlgorithm}</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Last Synced:</span>
                        <span className="text-slate-400 font-mono text-[11px] tabular-nums">
                          {new Date(dest.lastSyncAt).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>

                    {/* Supported IDs */}
                    <div className="pt-2 border-t border-slate-800/60">
                      <span className="text-[10px] text-slate-500 font-mono block mb-1">SUPPORTED IDENTITY KEYS</span>
                      <div className="flex flex-wrap gap-1">
                        {dest.supportedIdentifiers.map((idKey, i) => (
                          <span
                            key={i}
                            className="text-[10px] font-mono text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800/80"
                          >
                            {idKey}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Push Action Button */}
                  <div className="pt-3 border-t border-slate-800/80">
                    <button
                      onClick={() => handleSyncDestination(dest.id)}
                      disabled={isSyncing || dest.status === 'paused'}
                      className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors disabled:opacity-40"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-cyan-400' : ''}`} />
                      <span>{isSyncing ? 'Pushing API Payload...' : 'Push Manual Sync'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-slate-200">Execution Audit Trail</h2>
                <p className="text-xs text-slate-400">Verifiable delivery logs for every audience dispatch event.</p>
              </div>
              <span className="text-xs text-slate-500 font-mono tabular-nums">{syncLogs.length} total dispatches</span>
            </div>

            <div className="border border-slate-800 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-mono">
                  <tr>
                    <th className="py-2.5 px-4 font-medium">Timestamp</th>
                    <th className="py-2.5 px-4 font-medium">Destination</th>
                    <th className="py-2.5 px-4 font-medium">Audience Segment</th>
                    <th className="py-2.5 px-4 font-medium text-right">Pushed</th>
                    <th className="py-2.5 px-4 font-medium text-right">Matched</th>
                    <th className="py-2.5 px-4 font-medium text-right">Match Rate</th>
                    <th className="py-2.5 px-4 font-medium text-right">Latency</th>
                    <th className="py-2.5 px-4 font-medium text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {syncLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-900/30">
                      <td className="py-2.5 px-4 text-slate-400 tabular-nums">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </td>
                      <td className="py-2.5 px-4 text-slate-200 font-sans font-medium">
                        {log.destinationName}
                      </td>
                      <td className="py-2.5 px-4 text-cyan-300 font-sans">
                        {log.segmentName}
                      </td>
                      <td className="py-2.5 px-4 text-slate-300 text-right tabular-nums">
                        {log.profilesPushed.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-emerald-400 text-right tabular-nums font-semibold">
                        {log.profilesMatched.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-cyan-400 text-right tabular-nums font-semibold">
                        {log.matchRate}%
                      </td>
                      <td className="py-2.5 px-4 text-slate-500 text-right tabular-nums">
                        {log.latencyMs}ms
                      </td>
                      <td className="py-2.5 px-4 text-center font-sans">
                        <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Delivered</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'hasher' && (
          <div className="max-w-2xl space-y-6">
            <div>
              <h2 className="text-sm font-semibold text-slate-200">Cryptographic Identity Hasher (SHA-256)</h2>
              <p className="text-xs text-slate-400">
                Nexus360 adheres strictly to Google Customer Match and Meta Advanced Matching standards by normalizing and hashing all PII locally in the browser/edge before transmission.
              </p>
            </div>

            <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Plaintext Email to Hash
                </label>
                <input
                  type="email"
                  value={hashInputEmail}
                  onChange={e => setHashInputEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <span className="text-[11px] text-slate-500 font-mono block mb-1">
                  OUTPUT: SHA-256 HEX DIGEST (SENT TO AD PLATFORMS)
                </span>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded font-mono text-xs text-cyan-300 break-all select-all">
                  {computedHash || 'Hashing...'}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 text-xs text-slate-400 space-y-1">
                <div className="flex items-center gap-2 text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                  <span className="font-medium">Strict Compliance Standards Verified</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Leading and trailing whitespaces are trimmed, characters converted to lowercase, and phone numbers standardized to ITU-T E.164 (+1XXXXXXXXXX).
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
export default ActivationHub;

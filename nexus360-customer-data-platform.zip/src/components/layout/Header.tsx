import React, { useState } from 'react';
import { useCDP, CDPView } from '../../context/CDPContext';
import { Zap, RefreshCw, Radio } from 'lucide-react';
import EventSimulatorModal from '../events/EventSimulatorModal';

export const Header: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    syncAllAudiences,
    isSyncingGlobal,
    isAutoStreaming,
    toggleAutoStream
  } = useCDP();

  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);

  const navItems: { id: CDPView; label: string }[] = [
    { id: 'customer360', label: 'Customer 360' },
    { id: 'identity_graph', label: 'Identity Graph' },
    { id: 'segments', label: 'Segments' },
    { id: 'activation', label: 'Ad Activation' },
    { id: 'events', label: 'Live Events' },
    { id: 'sources', label: 'Data Sources' }
  ];

  return (
    <>
      <header className="sticky top-0 z-40 flex items-center justify-between h-14 px-6 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => setCurrentView('customer360')}
          className="text-base font-semibold tracking-tight text-white hover:text-cyan-400 transition-colors text-left"
        >
          Nexus360 CDP
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          {navItems.map(item => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`transition-colors whitespace-nowrap py-1 relative ${
                  isActive
                    ? 'text-cyan-400 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleAutoStream}
            title={isAutoStreaming ? 'Live event stream is running' : 'Start automatic live event feed'}
            className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap border ${
              isAutoStreaming
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-700/50 hover:bg-emerald-900/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <Radio className={`w-3.5 h-3.5 ${isAutoStreaming ? 'animate-pulse text-emerald-400' : ''}`} />
            <span>{isAutoStreaming ? 'Streaming Live' : 'Feed Paused'}</span>
          </button>

          <button
            onClick={() => setIsSimulatorOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700/70 rounded transition-colors whitespace-nowrap shadow-sm"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Ingest Event</span>
          </button>

          <button
            onClick={syncAllAudiences}
            disabled={isSyncingGlobal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap disabled:opacity-50 shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingGlobal ? 'animate-spin' : ''}`} />
            <span>{isSyncingGlobal ? 'Syncing...' : 'Sync Audiences'}</span>
          </button>
        </div>
      </header>

      {/* Simulator Modal */}
      {isSimulatorOpen && (
        <EventSimulatorModal onClose={() => setIsSimulatorOpen(false)} />
      )}
    </>
  );
};
export default Header;

import React, { useState, useMemo } from 'react';
import { useCDP } from '../../context/CDPContext';
import { GraphNode, GraphEdge, CustomerProfile } from '../../types/cdp';
import {
  Network,
  ShieldCheck,
  CheckCircle2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sparkles,
  Link,
  Layers,
  ArrowRight,
  Info
} from 'lucide-react';

export const IdentityGraphViewer: React.FC = () => {
  const { customers, selectedCustomerId, setSelectedCustomerId, stitchIdentities } = useCDP();

  const [activeCustomer, setActiveCustomer] = useState<CustomerProfile | null>(() => {
    return customers.find(c => c.id === selectedCustomerId) || customers[0] || null;
  });

  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<GraphEdge | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showStitchModal, setShowStitchModal] = useState<boolean>(false);
  const [stitchSourceId, setStitchSourceId] = useState<string>('');
  const [stitchTargetId, setStitchTargetId] = useState<string>('');
  const [stitchRule, setStitchRule] = useState<string>('Deterministic: Verified Email Form Fill');

  // Keep activeCustomer updated if customer state updates
  React.useEffect(() => {
    if (selectedCustomerId) {
      const match = customers.find(c => c.id === selectedCustomerId);
      if (match) setActiveCustomer(match);
    }
  }, [selectedCustomerId, customers]);

  const nodes = useMemo(() => activeCustomer?.identityGraph?.nodes || [], [activeCustomer]);
  const edges = useMemo(() => activeCustomer?.identityGraph?.edges || [], [activeCustomer]);

  // Layout node positions dynamically if coordinates are missing
  const positionedNodes = useMemo(() => {
    const total = nodes.length;
    if (total === 0) return [];
    
    // Find primary or center node
    const primaryNode = nodes.find(n => n.isPrimary) || nodes[0];
    const width = 640;
    const height = 420;
    const centerX = width / 2;
    const centerY = height / 2;

    return nodes.map((node, index) => {
      if (node.id === primaryNode.id) {
        return { ...node, x: centerX, y: centerY };
      }
      // Arrange non-primary nodes in an orbit circle
      const angle = ((index) / (total > 1 ? total - 1 : 1)) * 2 * Math.PI;
      const radius = 160;
      return {
        ...node,
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius
      };
    });
  }, [nodes]);

  const handleExecuteStitch = () => {
    if (!stitchSourceId || !stitchTargetId || stitchSourceId === stitchTargetId) return;
    stitchIdentities(stitchSourceId, stitchTargetId, stitchRule, 1.0);
    setShowStitchModal(false);
    setSelectedCustomerId(stitchTargetId);
  };

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'email':
        return { bg: 'fill-cyan-500/20', stroke: 'stroke-cyan-400', text: 'text-cyan-300' };
      case 'phone':
        return { bg: 'fill-emerald-500/20', stroke: 'stroke-emerald-400', text: 'text-emerald-300' };
      case 'anonymous_cookie':
        return { bg: 'fill-amber-500/20', stroke: 'stroke-amber-400', text: 'text-amber-300' };
      case 'stripe_customer_id':
        return { bg: 'fill-indigo-500/20', stroke: 'stroke-indigo-400', text: 'text-indigo-300' };
      case 'crm_lead_id':
        return { bg: 'fill-violet-500/20', stroke: 'stroke-violet-400', text: 'text-violet-300' };
      case 'mobile_idfa':
        return { bg: 'fill-fuchsia-500/20', stroke: 'stroke-fuchsia-400', text: 'text-fuchsia-300' };
      default:
        return { bg: 'fill-slate-500/20', stroke: 'stroke-slate-400', text: 'text-slate-300' };
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950">
      {/* Top Header */}
      <div className="p-4 px-6 border-b border-slate-800/80 bg-slate-900/40 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-sm font-semibold text-slate-100">Identity Resolution Graph</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Deterministic & Probabilistic Identity Stitching</span>
            <span aria-hidden="true">·</span>
            <span>Real-Time Graph Traversal</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Customer Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Subject Profile:</span>
            <select
              value={activeCustomer?.id || ''}
              onChange={e => {
                const found = customers.find(c => c.id === e.target.value);
                if (found) {
                  setActiveCustomer(found);
                  setSelectedCustomerId(found.id);
                  setSelectedNode(null);
                  setSelectedEdge(null);
                }
              }}
              className="text-xs bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {customers.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.canonicalId}) - {c.identifiers.length} IDs
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => {
              setStitchTargetId(activeCustomer?.id || customers[0]?.id || '');
              setStitchSourceId(customers.find(c => c.lifecycleStage === 'Anonymous')?.id || customers[1]?.id || '');
              setShowStitchModal(true);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap"
          >
            <Link className="w-3.5 h-3.5" />
            <span>Simulate Graph Merge</span>
          </button>
        </div>
      </div>

      {/* Main Graph Canvas and Inspector Area */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Canvas Area */}
        <div className="flex-1 relative bg-slate-950 flex items-center justify-center p-4 overflow-hidden select-none">
          {/* Canvas Background Grid */}
          <div
            className="absolute inset-0 opacity-[0.12] pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(#38bdf8 1px, transparent 1px)',
              backgroundSize: '24px 24px'
            }}
          />

          {/* Zoom controls */}
          <div className="absolute top-4 right-4 z-10 flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded">
            <button
              onClick={() => setZoomLevel(z => Math.min(1.6, z + 0.1))}
              className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoomLevel(z => Math.max(0.6, z - 0.1))}
              className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors"
              title="Reset Zoom"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* SVG Visualizer */}
          <div
            className="w-full h-full max-w-[800px] max-h-[500px] flex items-center justify-center transition-transform duration-200"
            style={{ transform: `scale(${zoomLevel})` }}
          >
            <svg
              viewBox="0 0 640 420"
              className="w-full h-full overflow-visible"
            >
              <defs>
                <linearGradient id="edgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Edges */}
              {edges.map(edge => {
                const srcNode = positionedNodes.find(n => n.id === edge.source);
                const tgtNode = positionedNodes.find(n => n.id === edge.target);
                if (!srcNode || !tgtNode) return null;

                const isEdgeSelected = selectedEdge?.id === edge.id;

                return (
                  <g key={edge.id} className="cursor-pointer" onClick={() => { setSelectedEdge(edge); setSelectedNode(null); }}>
                    <line
                      x1={srcNode.x}
                      y1={srcNode.y}
                      x2={tgtNode.x}
                      y2={tgtNode.y}
                      stroke={isEdgeSelected ? '#38bdf8' : '#334155'}
                      strokeWidth={isEdgeSelected ? '3' : '1.5'}
                      strokeDasharray={edge.confidence < 0.95 ? '4 4' : 'none'}
                    />
                    {/* Edge midpoint rule badge */}
                    <rect
                      x={(srcNode.x! + tgtNode.x!) / 2 - 40}
                      y={(srcNode.y! + tgtNode.y!) / 2 - 9}
                      width="80"
                      height="18"
                      rx="3"
                      fill="#0f172a"
                      stroke={isEdgeSelected ? '#38bdf8' : '#1e293b'}
                      strokeWidth="1"
                    />
                    <text
                      x={(srcNode.x! + tgtNode.x!) / 2}
                      y={(srcNode.y! + tgtNode.y!) / 2 + 3}
                      textAnchor="middle"
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="JetBrains Mono"
                    >
                      {(edge.confidence * 100).toFixed(0)}% Match
                    </text>
                  </g>
                );
              })}

              {/* Nodes */}
              {positionedNodes.map(node => {
                const color = getNodeColor(node.type);
                const isSelected = selectedNode?.id === node.id;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    className="cursor-pointer transition-transform hover:scale-105"
                    onClick={() => { setSelectedNode(node); setSelectedEdge(null); }}
                  >
                    {/* Outer glow if primary or selected */}
                    {(node.isPrimary || isSelected) && (
                      <circle
                        r={node.isPrimary ? 34 : 28}
                        className={node.isPrimary ? 'fill-cyan-500/10 stroke-cyan-400/40' : 'fill-slate-500/10 stroke-slate-400/40'}
                        strokeWidth="1"
                        strokeDasharray="3 3"
                      />
                    )}

                    {/* Node circle */}
                    <circle
                      r={node.isPrimary ? 26 : 22}
                      className={`${color.bg} ${isSelected ? 'stroke-white stroke-2' : `${color.stroke} stroke-[1.5]`}`}
                    />

                    {/* Icon or Type label inside */}
                    <text
                      textAnchor="middle"
                      dy="4"
                      fill="#f8fafc"
                      fontSize={node.isPrimary ? '10' : '9'}
                      fontWeight="600"
                      fontFamily="JetBrains Mono"
                    >
                      {node.type === 'anonymous_cookie' ? 'COOKIE' :
                       node.type === 'stripe_customer_id' ? 'STRIPE' :
                       node.type === 'crm_lead_id' ? 'CRM' :
                       node.type === 'mobile_idfa' ? 'IDFA' :
                       node.type === 'phone' ? 'PHONE' : 'EMAIL'}
                    </text>

                    {/* Bottom label */}
                    <text
                      textAnchor="middle"
                      dy={node.isPrimary ? 42 : 36}
                      fill="#cbd5e1"
                      fontSize="10"
                      fontWeight="500"
                      fontFamily="Plus Jakarta Sans"
                    >
                      {node.label.length > 22 ? `${node.label.substring(0, 20)}...` : node.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right Inspector & Rules Panel */}
        <div className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-slate-800/80 bg-slate-900/30 p-5 space-y-5 overflow-y-auto">
          {/* Node / Edge Inspector */}
          <div>
            <span className="text-[11px] text-slate-500 font-mono block mb-1">GRAPH INSPECTOR</span>
            {selectedNode ? (
              <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg space-y-2.5 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-200 capitalize">
                    {selectedNode.type.replace('_', ' ')}
                  </span>
                  {selectedNode.isPrimary && (
                    <span className="text-[10px] text-cyan-400 font-medium">Canonical Primary</span>
                  )}
                </div>
                <div className="text-xs font-mono text-cyan-300 break-all bg-slate-950 p-2 rounded border border-slate-800/80">
                  {selectedNode.label}
                </div>
                <div className="space-y-1 text-xs text-slate-400">
                  <div className="flex justify-between">
                    <span>Source System:</span>
                    <span className="text-slate-200">{selectedNode.source}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Deterministic:</span>
                    <span className="text-emerald-400">Yes (100% confidence)</span>
                  </div>
                </div>
              </div>
            ) : selectedEdge ? (
              <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg space-y-2.5 animate-in fade-in">
                <div className="text-xs font-semibold text-slate-200">
                  Identity Resolution Link
                </div>
                <div className="text-xs text-slate-300 font-mono">
                  {selectedEdge.rule}
                </div>
                <div className="space-y-1 text-xs text-slate-400">
                  <div className="flex justify-between">
                    <span>Confidence Score:</span>
                    <span className="text-emerald-400 font-mono tabular-nums">
                      {(selectedEdge.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Resolved At:</span>
                    <span className="text-slate-300 font-mono tabular-nums">
                      {new Date(selectedEdge.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-900/40 border border-slate-800/60 rounded-lg text-xs text-slate-400">
                Click any node or link in the graph above to inspect identifier lineage and verification proofs.
              </div>
            )}
          </div>

          {/* Resolution Rules Engine */}
          <div className="space-y-3 pt-2 border-t border-slate-800/80">
            <span className="text-[11px] text-slate-500 font-mono block">STITCHING RULES ENGINE</span>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 bg-slate-950 border border-slate-800/80 rounded">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>Exact Email Match</span>
                  <span className="text-emerald-400 font-mono">100%</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Deterministic merge across Web, Shopify, Stripe, and Salesforce.
                </p>
              </div>

              <div className="p-2.5 bg-slate-950 border border-slate-800/80 rounded">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>E.164 Phone Normalization</span>
                  <span className="text-emerald-400 font-mono">100%</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Standardizes country codes before deterministic graph stitching.
                </p>
              </div>

              <div className="p-2.5 bg-slate-950 border border-slate-800/80 rounded">
                <div className="flex items-center justify-between text-slate-200 font-medium">
                  <span>App JWT & IDFA Token</span>
                  <span className="text-emerald-400 font-mono">98%</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Binds mobile advertising identifier to customer session.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Stitch Modal */}
      {showStitchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-sm font-semibold text-slate-100">Merge & Stitch Identity Profiles</h2>
              <button onClick={() => setShowStitchModal(false)} className="text-slate-400 hover:text-slate-200 text-xs">Close</button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Select an anonymous or secondary profile to merge into a target canonical profile.
              All cookies, events, and purchase history will stitch into the target graph.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Source Profile (Will be merged)</label>
                <select
                  value={stitchSourceId}
                  onChange={e => setStitchSourceId(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono"
                >
                  <option value="">Select source profile...</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.canonicalId}) - {c.primaryEmail}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Canonical Profile (Will retain identity)</label>
                <select
                  value={stitchTargetId}
                  onChange={e => setStitchTargetId(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono"
                >
                  <option value="">Select target profile...</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.canonicalId}) - {c.primaryEmail}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Stitching Rule & Match Proof</label>
                <input
                  type="text"
                  value={stitchRule}
                  onChange={e => setStitchRule(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => setShowStitchModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteStitch}
                className="px-4 py-1.5 text-xs font-semibold bg-cyan-400 text-slate-950 rounded hover:bg-cyan-300"
              >
                Execute Stitch & Re-calculate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default IdentityGraphViewer;

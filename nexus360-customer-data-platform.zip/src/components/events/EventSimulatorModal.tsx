import React, { useState } from 'react';
import { useCDP } from '../../context/CDPContext';
import { CustomerEvent } from '../../types/cdp';
import { X, Zap, ArrowRight, CheckCircle2, Sparkles, Send } from 'lucide-react';

interface Props {
  onClose: () => void;
}

export const EventSimulatorModal: React.FC<Props> = ({ onClose }) => {
  const { ingestEvent, customers, setCurrentView, setSelectedCustomerId } = useCDP();
  const [tab, setTab] = useState<'presets' | 'custom'>('presets');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Custom event state
  const [eventName, setEventName] = useState('Order Completed');
  const [category, setCategory] = useState<CustomerEvent['category']>('ecom');
  const [source, setSource] = useState<CustomerEvent['source']>('Shopify');
  const [email, setEmail] = useState('dev.patel@horizon-ai.io');
  const [phone, setPhone] = useState('+16504129844');
  const [cookie, setCookie] = useState('nx_anon_30a9e710ff4');
  const [amount, setAmount] = useState('749');
  const [customKey, setCustomKey] = useState('utm_campaign');
  const [customVal, setCustomVal] = useState('q4_black_friday_preview');

  const handleRunPreset = (preset: {
    title: string;
    description: string;
    eventData: {
      customerId?: string;
      name: string;
      category: CustomerEvent['category'];
      source: CustomerEvent['source'];
      properties: Record<string, any>;
      identifiersSupplied: Record<string, string>;
    };
    targetView?: 'customer360' | 'identity_graph' | 'segments';
    targetCustomerId?: string;
  }) => {
    ingestEvent(preset.eventData);
    setSuccessToast(`Dispatched: ${preset.eventData.name}`);
    if (preset.targetCustomerId) {
      setSelectedCustomerId(preset.targetCustomerId);
    }
    setTimeout(() => {
      setSuccessToast(null);
      if (preset.targetView) {
        setCurrentView(preset.targetView);
      }
      onClose();
    }, 900);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const identifiers: Record<string, string> = {};
    if (email.trim()) identifiers.email = email.trim();
    if (phone.trim()) identifiers.phone = phone.trim();
    if (cookie.trim()) identifiers.cookie = cookie.trim();

    const properties: Record<string, any> = {
      timestamp: new Date().toISOString()
    };
    if (amount) properties.amount = Number(amount);
    if (customKey && customVal) properties[customKey] = customVal;

    ingestEvent({
      name: eventName,
      category,
      source,
      properties,
      identifiersSupplied: identifiers
    });

    setSuccessToast(`Dispatched custom event: ${eventName}`);
    setTimeout(() => {
      setSuccessToast(null);
      onClose();
    }, 800);
  };

  interface PresetItem {
    title: string;
    description: string;
    eventData: {
      customerId?: string;
      name: string;
      category: CustomerEvent['category'];
      source: CustomerEvent['source'];
      properties: Record<string, any>;
      identifiersSupplied: Record<string, string>;
    };
    targetView?: 'customer360' | 'identity_graph' | 'segments';
    targetCustomerId?: string;
  }

  const presets: PresetItem[] = [
    {
      title: 'Stitch Anonymous Web Cookie to New Lead (Identity Resolution)',
      description: 'Anonymous visitor #7819 completes a Lead Magnet Form. Binds cookie "nx_anon_98f12aae8802" to lukas.becker@fintech-berlin.de and builds identity graph link.',
      eventData: {
        name: 'Form Submitted: Enterprise Whitepaper',
        category: 'crm',
        source: 'Web JS SDK',
        properties: { formId: 'whitepaper_soc2', company: 'FinTech Berlin GmbH' },
        identifiersSupplied: {
          cookie: 'nx_anon_98f12aae8802',
          email: 'lukas.becker@fintech-berlin.de',
          phone: '+49170892019'
        }
      },
      targetView: 'identity_graph',
      targetCustomerId: 'cust_01j7x8a905'
    },
    {
      title: 'Cart Abandoner Converts to Paying Customer',
      description: 'Dev Patel purchases Scale Tier ($749). Increases LTV, removes abandoned cart state, and qualifies for Paid Customer segment.',
      eventData: {
        name: 'Order Completed: Scale Tier ($749)',
        category: 'ecom',
        source: 'Shopify',
        properties: { amount: 749, plan: 'Scale Tier Annual', discountCode: 'EARLYBIRD' },
        identifiersSupplied: {
          email: 'dev.patel@horizon-ai.io',
          phone: '+16504129844',
          cookie: 'nx_anon_30a9e710ff4'
        }
      },
      targetView: 'customer360',
      targetCustomerId: 'cust_01j7x8a903'
    },
    {
      title: 'Urgent Support Escalation: Spikes Churn Risk',
      description: 'Marcus Vance files frustrated API billing ticket. Churn risk increases by +25%, dynamically triggering At-Risk Churner ad activation audience!',
      eventData: {
        name: 'Zendesk Ticket Created: Production Down',
        category: 'crm',
        source: 'Zendesk',
        properties: { ticketId: 'ZD-9041', sentiment: 'Critical Angry', issue: 'Rate limit blocked batch checkout' },
        identifiersSupplied: {
          email: 'marcus.vance@vanguardhq.com'
        }
      },
      targetView: 'segments',
      targetCustomerId: 'cust_01j7x8a901'
    },
    {
      title: 'Meta Ad Retargeting Click Recorded',
      description: 'Elena Rostova clicks Instagram Win-Back Ad. Logs campaign touchpoint and resets recent engagement recency.',
      eventData: {
        name: 'Ad Click: Instagram Re-engagement',
        category: 'marketing',
        source: 'Meta Ads',
        properties: { campaign: 'ig_winback_fall26', creative: 'carousel_v3', utm_medium: 'cpc' },
        identifiersSupplied: {
          email: 'elena.rostova@aurorafintech.co'
        }
      },
      targetView: 'customer360',
      targetCustomerId: 'cust_01j7x8a902'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">CDP Event Ingestion Simulator</h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>Real-Time Identity Stitching</span>
                <span aria-hidden="true">·</span>
                <span>Segment Re-calculation</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-slate-800/80 bg-slate-950/40">
          <button
            onClick={() => setTab('presets')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              tab === 'presets'
                ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Guided Growth Scenarios
          </button>
          <button
            onClick={() => setTab('custom')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              tab === 'custom'
                ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Custom Event Payload
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {successToast && (
            <div className="flex items-center gap-2 px-4 py-2.5 bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs rounded animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successToast}</span>
            </div>
          )}

          {tab === 'presets' ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Trigger real CDP events to see real-time identity graph merging, LTV updates, and audience re-evaluation.
              </p>
              {presets.map((preset, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-slate-950/60 border border-slate-800 hover:border-slate-700 rounded transition-all group"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors">
                        {preset.title}
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {preset.description}
                      </p>
                      <div className="flex items-center gap-2 pt-1 text-[11px] font-mono text-slate-500">
                        <span>Source: {preset.eventData.source}</span>
                        <span aria-hidden="true">·</span>
                        <span>Event: {preset.eventData.name}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRunPreset(preset)}
                      className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 border border-slate-700 rounded transition-all"
                    >
                      <span>Dispatch</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <form onSubmit={handleCustomSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Event Name</label>
                  <input
                    type="text"
                    value={eventName}
                    onChange={e => setEventName(e.target.value)}
                    required
                    placeholder="e.g. Order Completed"
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Source Connector</label>
                  <select
                    value={source}
                    onChange={e => setSource(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Shopify">Shopify Storefront</option>
                    <option value="Web JS SDK">Web JavaScript SDK</option>
                    <option value="iOS App">iOS App SDK</option>
                    <option value="Stripe">Stripe Billing</option>
                    <option value="Salesforce CRM">Salesforce Sales Cloud</option>
                    <option value="Zendesk">Zendesk Support</option>
                    <option value="Google Ads">Google Ads Campaign</option>
                    <option value="Meta Ads">Meta Ads Pixel</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-xs font-semibold text-slate-300 block mb-2">Identifiers for Identity Stitching</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="user@company.com"
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Phone</label>
                    <input
                      type="text"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="+14155550199"
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Anonymous Cookie</label>
                    <input
                      type="text"
                      value={cookie}
                      onChange={e => setCookie(e.target.value)}
                      placeholder="nx_anon_..."
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-xs font-semibold text-slate-300 block mb-2">Event Properties & Financials</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Monetary Amount ($)</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={e => setAmount(e.target.value)}
                      placeholder="749"
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Custom Trait Key</label>
                    <input
                      type="text"
                      value={customKey}
                      onChange={e => setCustomKey(e.target.value)}
                      placeholder="planTier"
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Custom Trait Value</label>
                    <input
                      type="text"
                      value={customVal}
                      onChange={e => setCustomVal(e.target.value)}
                      placeholder="Enterprise"
                      className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Ingestion Event</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
export default EventSimulatorModal;

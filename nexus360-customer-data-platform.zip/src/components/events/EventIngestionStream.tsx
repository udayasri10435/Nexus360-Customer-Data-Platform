import React, { useState } from 'react';
import { useCDP } from '../../context/CDPContext';
import { CustomerEvent } from '../../types/cdp';
import {
  Radio,
  Filter,
  Zap,
  ArrowRight,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Layers,
  Database
} from 'lucide-react';
import EventSimulatorModal from './EventSimulatorModal';

export const EventIngestionStream: React.FC = () => {
  const {
    liveEvents,
    customers,
    setSelectedCustomerId,
    setCurrentView,
    isAutoStreaming,
    toggleAutoStream
  } = useCDP();

  const [selectedSource, setSelectedSource] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);

  const filteredEvents = liveEvents.filter(ev => {
    const matchSource = selectedSource === 'all' || ev.source === selectedSource;
    const matchCategory = selectedCategory === 'all' || ev.category === selectedCategory;
    return matchSource && matchCategory;
  });

  const handleInspectCustomer = (customerId: string) => {
    setSelectedCustomerId(customerId);
    setCurrentView('customer360');
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto">
      {/* Top Header */}
      <div className="p-6 border-b border-slate-800/80 bg-slate-900/40 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-slate-100">Real-Time Ingestion Stream</h1>
              <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 text-[11px] font-mono rounded ${
                isAutoStreaming
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${isAutoStreaming ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
                <span>{isAutoStreaming ? 'Live Socket Active' : 'Stream Paused'}</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Streaming event bus receiving raw telemetry from Web SDKs, Shopify, Stripe, and CRM.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={toggleAutoStream}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors border ${
                isAutoStreaming
                  ? 'bg-slate-900 text-slate-200 border-slate-700 hover:bg-slate-800'
                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-700 hover:bg-emerald-900'
              }`}
            >
              {isAutoStreaming ? 'Pause Stream' : 'Resume Live Stream'}
            </button>

            <button
              onClick={() => setIsSimulatorOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap shadow-sm"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Simulate Event</span>
            </button>
          </div>
        </div>

        {/* Filter row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/60">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium">Connector:</span>
            {['all', 'Web JS SDK', 'Shopify', 'Stripe', 'iOS App', 'Zendesk', 'Salesforce CRM'].map(src => (
              <button
                key={src}
                onClick={() => setSelectedSource(src)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                  selectedSource === src
                    ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {src}
              </button>
            ))}
          </div>

          <span className="text-xs font-mono text-slate-500 tabular-nums">
            {filteredEvents.length} events buffered
          </span>
        </div>
      </div>

      {/* Events Table / Stream */}
      <div className="p-6 flex-1 space-y-3">
        {filteredEvents.length === 0 ? (
          <div className="p-12 text-center space-y-2 border border-dashed border-slate-800 rounded-lg">
            <Database className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-xs text-slate-400">No events match the selected filters.</p>
            <button
              onClick={() => { setSelectedSource('all'); setSelectedCategory('all'); }}
              className="text-xs text-cyan-400 hover:underline"
            >
              Reset stream filters
            </button>
          </div>
        ) : (
          filteredEvents.map(ev => {
            const isExpanded = expandedId === ev.id;
            const targetCustomer = customers.find(c => c.id === ev.customerId);

            return (
              <div
                key={ev.id}
                className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg hover:border-slate-700 transition-colors"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-semibold text-slate-100 font-mono">
                        {ev.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {ev.source}
                      </span>
                      <span className="text-[10px] text-cyan-400 uppercase font-mono">
                        {ev.category}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="font-mono tabular-nums text-slate-500">
                        {new Date(ev.timestamp).toLocaleTimeString()}
                      </span>
                      <span aria-hidden="true">·</span>
                      {targetCustomer ? (
                        <button
                          onClick={() => handleInspectCustomer(targetCustomer.id)}
                          className="text-slate-300 hover:text-cyan-400 font-medium inline-flex items-center gap-1 transition-colors"
                        >
                          <span>Profile: {targetCustomer.name}</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      ) : (
                        <span className="text-slate-500 font-mono">Unattached Visitor</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : ev.id)}
                      className="text-xs text-slate-400 hover:text-cyan-400 font-mono inline-flex items-center gap-1 transition-colors"
                    >
                      <span>{isExpanded ? 'Collapse' : 'Inspect Payload'}</span>
                      {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Payload view */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2 text-xs font-mono animate-in fade-in">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-1">PROPERTIES PAYLOAD</span>
                        <pre className="bg-slate-950 p-3 rounded border border-slate-800 text-slate-300 overflow-x-auto">
                          {JSON.stringify(ev.properties, null, 2)}
                        </pre>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block mb-1">IDENTIFIERS SUPPLIED FOR STITCHING</span>
                        <pre className="bg-slate-950 p-3 rounded border border-slate-800 text-cyan-300 overflow-x-auto">
                          {JSON.stringify(ev.identifiersSupplied, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {isSimulatorOpen && (
        <EventSimulatorModal onClose={() => setIsSimulatorOpen(false)} />
      )}
    </div>
  );
};
export default EventIngestionStream;

import React, { useState, useMemo } from 'react';
import { useCDP } from '../../context/CDPContext';
import { CustomerProfile, LifecycleStage } from '../../types/cdp';
import { Search, Filter, ShieldCheck, AlertCircle, Sparkles, UserCheck, Layers } from 'lucide-react';

interface Props {
  onSelectCustomer: (id: string) => void;
  selectedId: string | null;
}

export const CustomerList: React.FC<Props> = ({ onSelectCustomer, selectedId }) => {
  const { customers } = useCDP();
  const [searchTerm, setSearchTerm] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'ltv' | 'lastActive' | 'churnRisk'>('ltv');

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      const matchSearch =
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.primaryEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.canonicalId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (c.company && c.company.toLowerCase().includes(searchTerm.toLowerCase())) ||
        c.identifiers.some(i => i.value.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchStage = stageFilter === 'all' || c.lifecycleStage === stageFilter;
      return matchSearch && matchStage;
    }).sort((a, b) => {
      if (sortBy === 'ltv') return b.ltv - a.ltv;
      if (sortBy === 'churnRisk') return b.churnRisk - a.churnRisk;
      return new Date(b.lastActiveAt).getTime() - new Date(a.lastActiveAt).getTime();
    });
  }, [customers, searchTerm, stageFilter, sortBy]);

  const stages: { label: string; value: string }[] = [
    { label: 'All Profiles', value: 'all' },
    { label: 'VIP', value: 'VIP Customer' },
    { label: 'Paying', value: 'Paying Customer' },
    { label: 'At-Risk', value: 'At-Risk' },
    { label: 'Free Trial', value: 'Free Trial' },
    { label: 'Anonymous', value: 'Anonymous' }
  ];

  return (
    <div className="flex flex-col h-full bg-slate-950 border-r border-slate-800/80">
      {/* Search and Filters Header */}
      <div className="p-4 border-b border-slate-800/80 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-sm font-semibold text-slate-100">Profiles Directory</h1>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className="font-mono tabular-nums">{filteredCustomers.length}</span>
              <span>of</span>
              <span className="font-mono tabular-nums">{customers.length}</span>
              <span>unified profiles</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="text-xs bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-300 focus:outline-none focus:border-cyan-500 font-medium"
            >
              <option value="ltv">Sort: Highest LTV</option>
              <option value="churnRisk">Sort: Churn Risk</option>
              <option value="lastActive">Sort: Recently Active</option>
            </select>
          </div>
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search email, phone, cookie, ID, company..."
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Filter Segmented Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          {stages.map(s => (
            <button
              key={s.value}
              onClick={() => setStageFilter(s.value)}
              className={`px-2 py-1 text-[11px] font-medium rounded whitespace-nowrap transition-colors ${
                stageFilter === s.value
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Profile List Items */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-900">
        {filteredCustomers.length === 0 ? (
          <div className="p-8 text-center space-y-2">
            <p className="text-xs text-slate-400">No customer profiles match criteria.</p>
            <button
              onClick={() => { setSearchTerm(''); setStageFilter('all'); }}
              className="text-xs text-cyan-400 hover:underline"
            >
              Reset filters
            </button>
          </div>
        ) : (
          filteredCustomers.map(cust => {
            const isSelected = selectedId === cust.id;
            const nodesCount = cust.identityGraph?.nodes?.length || cust.identifiers.length;

            return (
              <button
                key={cust.id}
                onClick={() => onSelectCustomer(cust.id)}
                className={`w-full text-left p-3.5 transition-colors group ${
                  isSelected
                    ? 'bg-slate-900/90 border-l-2 border-cyan-400'
                    : 'hover:bg-slate-900/40 border-l-2 border-transparent'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-0.5 min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors truncate">
                        {cust.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">
                        {cust.canonicalId}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-400 truncate">
                      {cust.primaryEmail}
                    </div>

                    {cust.company && (
                      <div className="text-[10px] text-slate-500 truncate">
                        {cust.company}
                      </div>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-xs font-semibold text-slate-200 font-mono tabular-nums">
                      ${cust.ltv.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {cust.orderCount} orders
                    </div>
                  </div>
                </div>

                {/* Sub-row metadata using clean unboxed text and dot separators */}
                <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 pt-1.5 border-t border-slate-900/60">
                  <div className="flex items-center gap-1.5">
                    <span className={
                      cust.lifecycleStage === 'VIP Customer' ? 'text-amber-400 font-medium' :
                      cust.lifecycleStage === 'At-Risk' ? 'text-rose-400 font-medium' :
                      cust.lifecycleStage === 'Anonymous' ? 'text-slate-400' :
                      'text-cyan-400 font-medium'
                    }>
                      {cust.lifecycleStage}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{nodesCount} stitched ids</span>
                  </div>

                  {cust.churnRisk > 50 && (
                    <span className="text-rose-400/90 font-mono tabular-nums">
                      {cust.churnRisk}% churn risk
                    </span>
                  )}
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
};
export default CustomerList;

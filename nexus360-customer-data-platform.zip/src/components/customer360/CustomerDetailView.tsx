import React, { useState } from 'react';
import { useCDP } from '../../context/CDPContext';
import { CustomerProfile, CustomerEvent } from '../../types/cdp';
import {
  ShieldCheck,
  Zap,
  Network,
  Share2,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  ExternalLink,
  Copy,
  Check,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Link as LinkIcon
} from 'lucide-react';

interface Props {
  customer: CustomerProfile;
  onOpenGraphView?: () => void;
}

export const CustomerDetailView: React.FC<Props> = ({ customer, onOpenGraphView }) => {
  const { segments, destinations, ingestEvent, setCurrentView } = useCDP();
  const [activeTab, setActiveTab] = useState<'timeline' | 'identity' | 'segments' | 'traits'>('timeline');
  const [copiedId, setCopiedId] = useState(false);
  const [expandedEventId, setExpandedEventId] = useState<string | null>(null);
  const [timelineCategory, setTimelineCategory] = useState<string>('all');
  const [isStitchOpen, setIsStitchOpen] = useState(false);
  const [newIdentifierType, setNewIdentifierType] = useState<string>('email');
  const [newIdentifierVal, setNewIdentifierVal] = useState<string>('');

  const handleCopyId = () => {
    navigator.clipboard.writeText(customer.canonicalId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const matchingSegments = segments.filter(seg => seg.profileCount > 0); // or evaluate against customer

  const filteredEvents = customer.recentEvents.filter(ev => {
    if (timelineCategory === 'all') return true;
    return ev.category === timelineCategory;
  });

  const handleQuickStitch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIdentifierVal.trim()) return;

    ingestEvent({
      customerId: customer.id,
      name: `Identity Linked: ${newIdentifierType}`,
      category: 'crm',
      source: 'Salesforce CRM',
      properties: { manualStitch: true, addedType: newIdentifierType },
      identifiersSupplied: { [newIdentifierType]: newIdentifierVal.trim() }
    });

    setNewIdentifierVal('');
    setIsStitchOpen(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-y-auto">
      {/* Profile Header */}
      <div className="p-6 border-b border-slate-800/80 bg-slate-900/30 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-slate-800 border border-slate-700/80 flex items-center justify-center text-slate-100 font-semibold text-lg shrink-0">
              {customer.avatarInitials}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <h1 className="text-lg font-bold text-slate-100">{customer.name}</h1>
                <button
                  onClick={handleCopyId}
                  className="flex items-center gap-1 px-2 py-0.5 text-[11px] font-mono text-slate-400 bg-slate-900 border border-slate-800 rounded hover:text-slate-200 transition-colors"
                >
                  <span>{customer.canonicalId}</span>
                  {copiedId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                <span>{customer.primaryEmail}</span>
                <span aria-hidden="true">·</span>
                <span>{customer.primaryPhone}</span>
                {customer.company && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-slate-300">{customer.role ? `${customer.role} at ` : ''}{customer.company}</span>
                  </>
                )}
                <span aria-hidden="true">·</span>
                <span>{customer.city}, {customer.country}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (onOpenGraphView) onOpenGraphView();
                else setCurrentView('identity_graph');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded transition-colors whitespace-nowrap"
            >
              <Network className="w-3.5 h-3.5 text-cyan-400" />
              <span>Identity Graph</span>
            </button>
            <button
              onClick={() => setIsStitchOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap"
            >
              <LinkIcon className="w-3.5 h-3.5" />
              <span>Link Identifier</span>
            </button>
          </div>
        </div>

        {/* Quick stitch drawer / popup */}
        {isStitchOpen && (
          <form onSubmit={handleQuickStitch} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex flex-wrap items-center gap-3 animate-in fade-in">
            <span className="text-xs font-medium text-slate-300">Link New Identifier to Graph:</span>
            <select
              value={newIdentifierType}
              onChange={e => setNewIdentifierType(e.target.value)}
              className="text-xs bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200"
            >
              <option value="email">Email</option>
              <option value="phone">Phone</option>
              <option value="anonymous_cookie">Anonymous Cookie</option>
              <option value="stripe_customer_id">Stripe Customer ID</option>
              <option value="crm_lead_id">Salesforce Lead ID</option>
              <option value="mobile_idfa">Mobile IDFA / GAID</option>
            </select>
            <input
              type="text"
              value={newIdentifierVal}
              onChange={e => setNewIdentifierVal(e.target.value)}
              placeholder="Enter identifier value..."
              required
              className="text-xs bg-slate-950 border border-slate-700 rounded px-3 py-1 text-slate-200 flex-1 min-w-[200px] font-mono"
            />
            <button
              type="submit"
              className="text-xs font-semibold px-3 py-1 bg-cyan-400 text-slate-950 rounded hover:bg-cyan-300"
            >
              Resolve & Merge
            </button>
            <button
              type="button"
              onClick={() => setIsStitchOpen(false)}
              className="text-xs text-slate-400 hover:text-slate-200"
            >
              Cancel
            </button>
          </form>
        )}

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 pt-2">
          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded">
            <span className="text-[11px] text-slate-400 block mb-0.5">Lifetime Value (LTV)</span>
            <span className="text-base font-bold text-slate-100 font-mono tabular-nums">
              ${customer.ltv.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {customer.orderCount} orders · ${customer.avgOrderValue.toFixed(0)} avg
            </span>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded">
            <span className="text-[11px] text-slate-400 block mb-0.5">Churn Risk Score</span>
            <div className="flex items-center gap-1.5">
              <span className={`text-base font-bold font-mono tabular-nums ${
                customer.churnRisk > 60 ? 'text-rose-400' :
                customer.churnRisk > 30 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {customer.churnRisk}%
              </span>
              <span className="text-[10px] text-slate-500">
                {customer.churnRisk > 60 ? 'High' : customer.churnRisk > 30 ? 'Medium' : 'Low'}
              </span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              ML Propensity Model
            </span>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded">
            <span className="text-[11px] text-slate-400 block mb-0.5">RFM Score</span>
            <div className="text-base font-bold text-slate-100 font-mono tabular-nums">
              {customer.rfmScore.recency}-{customer.rfmScore.frequency}-{customer.rfmScore.monetary}
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              R:{customer.rfmScore.recency}/5 · F:{customer.rfmScore.frequency}/5 · M:{customer.rfmScore.monetary}/5
            </span>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded">
            <span className="text-[11px] text-slate-400 block mb-0.5">NPS Feedback</span>
            <span className="text-base font-bold text-slate-100 font-mono tabular-nums">
              {customer.npsScore > 0 ? `${customer.npsScore} / 10` : 'No score'}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {customer.npsScore >= 9 ? 'Promoter' : customer.npsScore >= 7 ? 'Passive' : 'Detractor'}
            </span>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded">
            <span className="text-[11px] text-slate-400 block mb-0.5">Preferred Channel</span>
            <span className="text-xs font-medium text-slate-200 truncate block mt-1">
              {customer.preferredChannel}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              Highest conversion lift
            </span>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded">
            <span className="text-[11px] text-slate-400 block mb-0.5">Privacy Consent</span>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium mt-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Opted-in</span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              GDPR & CCPA Compliant
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1 px-6 border-b border-slate-800/80 bg-slate-950">
        <button
          onClick={() => setActiveTab('timeline')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'timeline'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Activity Timeline ({customer.recentEvents.length})
        </button>
        <button
          onClick={() => setActiveTab('identity')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'identity'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Stitched Identifiers ({customer.identifiers.length})
        </button>
        <button
          onClick={() => setActiveTab('segments')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'segments'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Dynamic Segments ({customer.segmentIds.length})
        </button>
        <button
          onClick={() => setActiveTab('traits')}
          className={`px-4 py-3 text-xs font-medium border-b-2 transition-colors ${
            activeTab === 'traits'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Traits & Custom Attributes
        </button>
      </div>

      {/* Tab Contents */}
      <div className="p-6 flex-1">
        {activeTab === 'timeline' && (
          <div className="space-y-4">
            {/* Filter buttons */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {['all', 'web', 'ecom', 'crm', 'billing', 'marketing'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setTimelineCategory(cat)}
                    className={`px-2.5 py-1 text-[11px] font-medium rounded transition-colors ${
                      timelineCategory === cat
                        ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cat === 'all' ? 'All Channels' : cat.toUpperCase()}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-500 font-mono tabular-nums">
                {filteredEvents.length} events logged
              </span>
            </div>

            {/* Event Timeline List */}
            <div className="space-y-2 border-l border-slate-800 ml-3 pl-4">
              {filteredEvents.map(ev => {
                const isExpanded = expandedEventId === ev.id;
                return (
                  <div
                    key={ev.id}
                    className="p-3 bg-slate-900/60 border border-slate-800/80 rounded hover:border-slate-700 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-200">
                            {ev.name}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {ev.source}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500">
                          <span className="font-mono tabular-nums">
                            {new Date(ev.timestamp).toLocaleString()}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>Category: {ev.category}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => setExpandedEventId(isExpanded ? null : ev.id)}
                        className="text-[11px] text-slate-400 hover:text-cyan-400 font-mono transition-colors flex items-center gap-1"
                      >
                        <span>{isExpanded ? 'Hide Payload' : 'View Payload'}</span>
                        {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2 text-xs font-mono">
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-300 overflow-x-auto">
                          <pre>{JSON.stringify({ properties: ev.properties, identifiers: ev.identifiersSupplied }, null, 2)}</pre>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'identity' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-sm font-semibold text-slate-200">Resolved Identity Nodes</h2>
              <p className="text-xs text-slate-400">
                Deterministic and probabilistic links stitched into canonical profile {customer.canonicalId}.
              </p>
            </div>

            {/* Table of identifiers */}
            <div className="border border-slate-800 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400">
                  <tr>
                    <th className="py-2.5 px-4 font-medium">Identifier Type</th>
                    <th className="py-2.5 px-4 font-medium">Identifier Value</th>
                    <th className="py-2.5 px-4 font-medium">Origin Source</th>
                    <th className="py-2.5 px-4 font-medium">Match Confidence</th>
                    <th className="py-2.5 px-4 font-medium">Verified Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {customer.identifiers.map(id => (
                    <tr key={id.id} className="hover:bg-slate-900/30">
                      <td className="py-2.5 px-4 font-sans text-slate-300 flex items-center gap-2">
                        {id.isPrimary && (
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" title="Primary Identity" />
                        )}
                        <span>{id.type}</span>
                      </td>
                      <td className="py-2.5 px-4 text-cyan-300 font-mono">{id.value}</td>
                      <td className="py-2.5 px-4 text-slate-400 font-sans">{id.source}</td>
                      <td className="py-2.5 px-4 text-emerald-400 tabular-nums">
                        {(id.confidence * 100).toFixed(0)}% (Deterministic)
                      </td>
                      <td className="py-2.5 px-4 text-slate-500 tabular-nums">
                        {new Date(id.lastSeen).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Match Rules Log */}
            <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-lg space-y-2">
              <h3 className="text-xs font-semibold text-slate-200">Identity Resolution Edges</h3>
              <div className="space-y-1.5 text-xs text-slate-400">
                {customer.identityGraph.edges.map(edge => (
                  <div key={edge.id} className="flex items-center justify-between py-1 border-b border-slate-800/40">
                    <span className="text-slate-300 font-mono">{edge.rule}</span>
                    <span className="text-emerald-400 font-mono tabular-nums">
                      {(edge.confidence * 100).toFixed(0)}% Confidence
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'segments' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-slate-200">Matched Dynamic Segments</h2>
                <p className="text-xs text-slate-400">Audiences this customer qualifies for in real-time.</p>
              </div>
              <button
                onClick={() => setCurrentView('segments')}
                className="text-xs text-cyan-400 hover:underline flex items-center gap-1"
              >
                <span>Segment Builder</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {matchingSegments.map(seg => (
                <div
                  key={seg.id}
                  className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200">{seg.name}</span>
                    <span className="text-[10px] text-cyan-400 font-mono">{seg.category}</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {seg.description}
                  </p>
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Syncs to: {seg.syncDestinations.length} ad channels</span>
                    <span className="font-mono tabular-nums">{seg.matchRatePercent}% match</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'traits' && (
          <div className="space-y-4">
            <h2 className="text-sm font-semibold text-slate-200">Computed Traits & Attributes</h2>
            <div className="border border-slate-800 rounded-lg divide-y divide-slate-800">
              {Object.entries(customer.traits).map(([key, val]) => (
                <div key={key} className="p-3 flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-400">{key}</span>
                  <span className="font-semibold text-slate-200 font-mono">
                    {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
export default CustomerDetailView;

import React, { useState, useMemo } from 'react';
import { useCDP } from '../../context/CDPContext';
import { Segment, SegmentRule, OperatorType } from '../../types/cdp';
import {
  Layers,
  Plus,
  Trash2,
  RefreshCw,
  Share2,
  Check,
  Sparkles,
  ArrowRight,
  Sliders,
  DollarSign,
  TrendingUp,
  Download
} from 'lucide-react';

export const SegmentBuilder: React.FC = () => {
  const { segments, customers, destinations, createSegment, updateSegment, deleteSegment, triggerSync } = useCDP();

  const [selectedSegmentId, setSelectedSegmentId] = useState<string>(segments[0]?.id || '');
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // Form states for active or new segment
  const activeSegment = useMemo(() => {
    return segments.find(s => s.id === selectedSegmentId) || segments[0];
  }, [segments, selectedSegmentId]);

  const [formName, setFormName] = useState(activeSegment?.name || '');
  const [formDescription, setFormDescription] = useState(activeSegment?.description || '');
  const [formCategory, setFormCategory] = useState<Segment['category']>(activeSegment?.category || 'High Value');
  const [combinator, setCombinator] = useState<'AND' | 'OR'>(activeSegment?.rules.combinator || 'AND');
  const [rules, setRules] = useState<SegmentRule[]>(activeSegment?.rules.rules || []);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>(activeSegment?.syncDestinations || []);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [syncingSegId, setSyncingSegId] = useState<string | null>(null);

  // Update form fields when active segment changes
  React.useEffect(() => {
    if (!isCreatingNew && activeSegment) {
      setFormName(activeSegment.name);
      setFormDescription(activeSegment.description);
      setFormCategory(activeSegment.category);
      setCombinator(activeSegment.rules.combinator);
      setRules(activeSegment.rules.rules);
      setSelectedDestinations(activeSegment.syncDestinations);
    }
  }, [activeSegment, isCreatingNew]);

  // Live audience estimation preview
  const previewMatchingCount = useMemo(() => {
    if (rules.length === 0) return customers.length;

    return customers.filter(cust => {
      const results = rules.map(rule => {
        let targetVal: any;
        if (rule.field.startsWith('traits.')) {
          const traitKey = rule.field.replace('traits.', '');
          targetVal = cust.traits?.[traitKey];
        } else if (rule.field.startsWith('consent.')) {
          const consentKey = rule.field.replace('consent.', '');
          targetVal = (cust.consent as any)?.[consentKey];
        } else if (rule.field === 'identifiers.length') {
          targetVal = cust.identifiers?.length || 0;
        } else {
          targetVal = (cust as any)[rule.field];
        }

        if (targetVal === undefined || targetVal === null) return false;

        switch (rule.operator) {
          case 'greater_than':
            return Number(targetVal) > Number(rule.value);
          case 'less_than':
            return Number(targetVal) < Number(rule.value);
          case 'equals':
            return String(targetVal).toLowerCase() === String(rule.value).toLowerCase();
          case 'not_equals':
            return String(targetVal).toLowerCase() !== String(rule.value).toLowerCase();
          case 'contains':
            return String(targetVal).toLowerCase().includes(String(rule.value).toLowerCase());
          default:
            return true;
        }
      });

      return combinator === 'OR' ? results.some(Boolean) : results.every(Boolean);
    }).length;
  }, [customers, rules, combinator]);

  const previewPercentage = customers.length > 0 ? Math.round((previewMatchingCount / customers.length) * 100) : 0;

  const handleAddRule = () => {
    const newRule: SegmentRule = {
      id: `r_${Date.now()}`,
      field: 'ltv',
      operator: 'greater_than',
      value: 1000
    };
    setRules([...rules, newRule]);
  };

  const handleUpdateRule = (id: string, updates: Partial<SegmentRule>) => {
    setRules(rules.map(r => r.id === id ? { ...r, ...updates } : r));
  };

  const handleRemoveRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  const handleToggleDestination = (destId: string) => {
    if (selectedDestinations.includes(destId)) {
      setSelectedDestinations(selectedDestinations.filter(d => d !== destId));
    } else {
      setSelectedDestinations([...selectedDestinations, destId]);
    }
  };

  const handleSaveSegment = () => {
    if (!formName.trim()) return;

    if (isCreatingNew) {
      createSegment({
        name: formName,
        description: formDescription,
        category: formCategory,
        rules: { combinator, rules },
        syncDestinations: selectedDestinations,
        status: 'active',
        projectedRoas: 4.2
      });
      setIsCreatingNew(false);
    } else if (activeSegment) {
      updateSegment(activeSegment.id, {
        name: formName,
        description: formDescription,
        category: formCategory,
        rules: { combinator, rules },
        syncDestinations: selectedDestinations
      });
    }

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleApplyTemplate = (templateName: string) => {
    if (templateName === 'churn') {
      setFormName('High-Value At-Risk Churners');
      setFormDescription('Customers with high spend experiencing disengagement or complaints.');
      setFormCategory('Retention');
      setCombinator('AND');
      setRules([
        { id: 't1', field: 'ltv', operator: 'greater_than', value: 1000 },
        { id: 't2', field: 'churnRisk', operator: 'greater_than', value: 60 }
      ]);
    } else if (templateName === 'vip') {
      setFormName('VIP Power Spenders ($2,500+)');
      setFormDescription('Top 5% highest contributing customers by lifetime value.');
      setFormCategory('High Value');
      setCombinator('AND');
      setRules([
        { id: 't3', field: 'ltv', operator: 'greater_than', value: 2500 },
        { id: 't4', field: 'orderCount', operator: 'greater_than', value: 3 }
      ]);
    } else if (templateName === 'cart') {
      setFormName('Abandoned High Value Cart ($500+)');
      setFormDescription('Shoppers who added products over $500 with marketing consent.');
      setFormCategory('Acquisition');
      setCombinator('AND');
      setRules([
        { id: 't5', field: 'traits.activeCartValue', operator: 'greater_than', value: 500 },
        { id: 't6', field: 'consent.marketing', operator: 'equals', value: 'true' }
      ]);
    }
  };

  const handleSyncThisSegment = async (segId: string) => {
    setSyncingSegId(segId);
    await triggerSync(segId);
    setSyncingSegId(null);
  };

  const handleExportCSV = () => {
    const matchingCusts = customers.filter(c => previewMatchingCount > 0);
    const headers = 'CanonicalID,Name,Email,Phone,LTV,Orders,ChurnRisk\n';
    const rows = matchingCusts.map(c => `"${c.canonicalId}","${c.name}","${c.primaryEmail}","${c.primaryPhone}",${c.ltv},${c.orderCount},${c.churnRisk}`).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus_cdp_segment_${formName.toLowerCase().replace(/\s+/g, '_')}.csv`;
    a.click();
  };

  return (
    <div className="flex flex-col lg:flex-row h-full bg-slate-950">
      {/* Left List of Segments */}
      <div className="w-full lg:w-80 border-r border-slate-800/80 flex flex-col bg-slate-950">
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-semibold text-slate-100">Dynamic Audiences</h1>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className="font-mono tabular-nums">{segments.length}</span>
              <span>active audience segments</span>
            </div>
          </div>
          <button
            onClick={() => {
              setIsCreatingNew(true);
              setFormName('New Behavioral Audience');
              setFormDescription('Custom rule-based audience segment for real-time activation.');
              setFormCategory('Acquisition');
              setCombinator('AND');
              setRules([{ id: `r_${Date.now()}`, field: 'ltv', operator: 'greater_than', value: 500 }]);
              setSelectedDestinations(['dest_google_ads', 'dest_meta_ads']);
            }}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Segment</span>
          </button>
        </div>

        {/* Segments listing */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-900">
          {segments.map(seg => {
            const isSelected = !isCreatingNew && selectedSegmentId === seg.id;
            const isSyncing = syncingSegId === seg.id || seg.status === 'syncing';

            return (
              <div
                key={seg.id}
                onClick={() => {
                  setIsCreatingNew(false);
                  setSelectedSegmentId(seg.id);
                }}
                className={`p-4 cursor-pointer transition-colors group ${
                  isSelected
                    ? 'bg-slate-900/90 border-l-2 border-cyan-400'
                    : 'hover:bg-slate-900/40 border-l-2 border-transparent'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1 flex-1 min-w-0">
                    <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors truncate block">
                      {seg.name}
                    </span>
                    <p className="text-[11px] text-slate-400 line-clamp-1">
                      {seg.description}
                    </p>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSyncThisSegment(seg.id);
                    }}
                    title="Push audience to ad networks"
                    className="p-1.5 text-slate-400 hover:text-cyan-400 bg-slate-900 hover:bg-slate-800 rounded border border-slate-800 transition-colors shrink-0"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-cyan-400' : ''}`} />
                  </button>
                </div>

                <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-900/60 font-mono">
                  <div className="flex items-center gap-1.5">
                    <span className="text-cyan-300 font-semibold tabular-nums">
                      {seg.profileCount} profiles
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{seg.matchRatePercent}% match</span>
                  </div>
                  <span className="text-slate-400 font-sans">{seg.category}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Segment Editor & Audience Intelligence */}
      <div className="flex-1 flex flex-col overflow-y-auto bg-slate-950">
        {/* Editor Top Bar */}
        <div className="p-6 border-b border-slate-800/80 bg-slate-900/30 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-100">
                  {isCreatingNew ? 'Create Real-Time Audience' : 'Audience Rule Configuration'}
                </h2>
                {saveSuccess && (
                  <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium animate-in fade-in">
                    <Check className="w-3.5 h-3.5" />
                    <span>Saved & Evaluated</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Segment rules evaluate instantaneously across all unified Customer 360 records.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Recipe templates dropdown */}
              <select
                onChange={e => handleApplyTemplate(e.target.value)}
                defaultValue=""
                className="text-xs bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-300 focus:outline-none focus:border-cyan-500 font-medium"
              >
                <option value="" disabled>Load Recipe Template...</option>
                <option value="churn">High-Value At-Risk Churners</option>
                <option value="vip">VIP Power Spenders ($2,500+)</option>
                <option value="cart">Cart Abandoners with High Intent</option>
              </select>

              <button
                onClick={handleExportCSV}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded transition-colors whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={handleSaveSegment}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap shadow-sm"
              >
                <Check className="w-3.5 h-3.5" />
                <span>{isCreatingNew ? 'Create & Activate' : 'Save Rules'}</span>
              </button>
            </div>
          </div>

          {/* Audience Sizing Metric Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-slate-950 border border-slate-800 rounded-lg">
            <div>
              <span className="text-[10px] text-slate-500 font-mono block">QUALIFIED PROFILES</span>
              <span className="text-base font-bold text-slate-100 font-mono tabular-nums">
                {previewMatchingCount}
              </span>
              <span className="text-[10px] text-slate-400 block">
                {previewPercentage}% of total base
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-mono block">EST. META MATCH REACH</span>
              <span className="text-base font-bold text-cyan-400 font-mono tabular-nums">
                {Math.round(previewMatchingCount * 0.79)} profiles
              </span>
              <span className="text-[10px] text-slate-400 block">
                79.2% benchmark match
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-mono block">EST. GOOGLE MATCH REACH</span>
              <span className="text-base font-bold text-cyan-400 font-mono tabular-nums">
                {Math.round(previewMatchingCount * 0.81)} profiles
              </span>
              <span className="text-[10px] text-slate-400 block">
                81.4% benchmark match
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-mono block">PROJECTED ROAS</span>
              <span className="text-base font-bold text-emerald-400 font-mono tabular-nums">
                {activeSegment?.projectedRoas || 4.2}x
              </span>
              <span className="text-[10px] text-slate-400 block">
                Cross-channel activation
              </span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-6 flex-1">
          {/* Metadata Section */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Segment Name</label>
              <input
                type="text"
                value={formName}
                onChange={e => setFormName(e.target.value)}
                placeholder="e.g. VIP Spenders ($2,500+)"
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-cyan-500 font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
              <select
                value={formCategory}
                onChange={e => setFormCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded text-slate-100 focus:outline-none focus:border-cyan-500"
              >
                <option value="High Value">High Value</option>
                <option value="Retention">Retention</option>
                <option value="Acquisition">Acquisition</option>
                <option value="Winback">Winback</option>
                <option value="Engagement">Engagement</option>
              </select>
            </div>
            <div className="sm:col-span-3">
              <label className="block text-xs font-medium text-slate-300 mb-1">Description</label>
              <input
                type="text"
                value={formDescription}
                onChange={e => setFormDescription(e.target.value)}
                placeholder="Explain the targeting goal of this segment..."
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded text-slate-300 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Logic Rules Section */}
          <div className="space-y-4 pt-2 border-t border-slate-800/80">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-slate-200">Rule Criteria</span>
                {/* Combinator toggle */}
                <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded text-xs font-medium">
                  <button
                    onClick={() => setCombinator('AND')}
                    className={`px-2.5 py-0.5 rounded transition-colors ${
                      combinator === 'AND'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Match ALL (AND)
                  </button>
                  <button
                    onClick={() => setCombinator('OR')}
                    className={`px-2.5 py-0.5 rounded transition-colors ${
                      combinator === 'OR'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Match ANY (OR)
                  </button>
                </div>
              </div>

              <button
                onClick={handleAddRule}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Condition</span>
              </button>
            </div>

            {/* Rule items */}
            <div className="space-y-2.5">
              {rules.map((rule, idx) => (
                <div
                  key={rule.id}
                  className="flex flex-wrap items-center gap-2 p-3 bg-slate-900/60 border border-slate-800 rounded-lg text-xs"
                >
                  <span className="text-slate-500 font-mono text-[11px] w-6 text-center">
                    {idx === 0 ? 'IF' : combinator}
                  </span>

                  {/* Field selector */}
                  <select
                    value={rule.field}
                    onChange={e => handleUpdateRule(rule.id, { field: e.target.value })}
                    className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                  >
                    <option value="ltv">Customer LTV ($)</option>
                    <option value="orderCount">Total Order Count</option>
                    <option value="churnRisk">Churn Risk Score (%)</option>
                    <option value="npsScore">NPS Feedback Score</option>
                    <option value="identifiers.length">Stitched Identifiers Count</option>
                    <option value="traits.activeCartValue">Cart Value ($)</option>
                    <option value="consent.marketing">Consent: Marketing Opt-in</option>
                    <option value="lifecycleStage">Lifecycle Stage</option>
                    <option value="country">Country</option>
                  </select>

                  {/* Operator selector */}
                  <select
                    value={rule.operator}
                    onChange={e => handleUpdateRule(rule.id, { operator: e.target.value as OperatorType })}
                    className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                  >
                    <option value="greater_than">greater than (&gt;)</option>
                    <option value="less_than">less than (&lt;)</option>
                    <option value="equals">equals (=)</option>
                    <option value="not_equals">not equals (!=)</option>
                    <option value="contains">contains text</option>
                  </select>

                  {/* Value input */}
                  <input
                    type="text"
                    value={rule.value}
                    onChange={e => handleUpdateRule(rule.id, { value: e.target.value })}
                    placeholder="Value..."
                    className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded text-slate-200 font-mono flex-1 min-w-[120px] focus:outline-none focus:border-cyan-500"
                  />

                  {/* Delete rule */}
                  <button
                    onClick={() => handleRemoveRule(rule.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                    title="Remove condition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Destination Activation Targets */}
          <div className="space-y-3 pt-4 border-t border-slate-800/80">
            <span className="text-xs font-semibold text-slate-200 block">
              Active Sync Destinations
            </span>
            <p className="text-xs text-slate-400">
              When triggered, qualified profiles will automatically be hashed (SHA-256) and synced to these ad and marketing networks.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
              {destinations.map(dest => {
                const isSelected = selectedDestinations.includes(dest.id);
                return (
                  <button
                    key={dest.id}
                    type="button"
                    onClick={() => handleToggleDestination(dest.id)}
                    className={`p-3 text-left border rounded-lg transition-all ${
                      isSelected
                        ? 'bg-slate-900 border-cyan-500/60 shadow-sm'
                        : 'bg-slate-950/40 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold text-slate-200">{dest.name}</span>
                      <div className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${
                        isSelected ? 'bg-cyan-400 border-cyan-400 text-slate-950' : 'border-slate-700'
                      }`}>
                        {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>{dest.hashingAlgorithm}</span>
                      <span className="tabular-nums">{dest.matchRateBenchmark}% match</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SegmentBuilder;

import { CustomerProfile, Segment, Destination, SyncExecutionLog, DataSource, CustomerEvent } from '../types/cdp';

export const INITIAL_CUSTOMERS: CustomerProfile[] = [
  {
    id: 'cust_01j7x8a901',
    canonicalId: 'NX-901842',
    name: 'Marcus Vance',
    primaryEmail: 'marcus.vance@vanguardhq.com',
    primaryPhone: '+1 (415) 890-2134',
    company: 'Vanguard Media Group',
    role: 'Chief Revenue Officer',
    avatarInitials: 'MV',
    lifecycleStage: 'VIP Customer',
    ltv: 14850,
    orderCount: 18,
    avgOrderValue: 825,
    churnRisk: 12,
    npsScore: 10,
    rfmScore: { recency: 5, frequency: 5, monetary: 5 },
    firstSeenAt: '2025-11-14T08:32:00Z',
    lastActiveAt: '2026-09-28T18:45:00Z',
    country: 'United States',
    city: 'San Francisco, CA',
    preferredChannel: 'Email',
    consent: {
      marketing: true,
      analytics: true,
      ccpaOptOut: false,
      gdprCompliant: true,
      updatedAt: '2026-08-10T14:22:00Z'
    },
    identifiers: [
      {
        id: 'id_101',
        type: 'email',
        value: 'marcus.vance@vanguardhq.com',
        source: 'Salesforce CRM',
        confidence: 1.0,
        firstSeen: '2025-11-14T08:32:00Z',
        lastSeen: '2026-09-28T18:45:00Z',
        isPrimary: true
      },
      {
        id: 'id_102',
        type: 'phone',
        value: '+14158902134',
        source: 'Stripe Billing',
        confidence: 1.0,
        firstSeen: '2025-11-18T10:15:00Z',
        lastSeen: '2026-09-25T11:00:00Z'
      },
      {
        id: 'id_103',
        type: 'anonymous_cookie',
        value: 'nx_anon_7b99c01ff8a',
        source: 'Web JS SDK',
        confidence: 0.98,
        firstSeen: '2025-11-12T19:22:00Z',
        lastSeen: '2026-09-28T18:45:00Z'
      },
      {
        id: 'id_104',
        type: 'stripe_customer_id',
        value: 'cus_Q98xLm01K99',
        source: 'Stripe Billing',
        confidence: 1.0,
        firstSeen: '2025-11-18T10:15:00Z',
        lastSeen: '2026-09-18T09:30:00Z'
      },
      {
        id: 'id_105',
        type: 'crm_lead_id',
        value: '0035G00002ab9X8QAA',
        source: 'Salesforce CRM',
        confidence: 1.0,
        firstSeen: '2025-11-14T08:32:00Z',
        lastSeen: '2026-09-20T16:00:00Z'
      },
      {
        id: 'id_106',
        type: 'mobile_idfa',
        value: 'E621E1F8-C36C-495A-93FC-0C247A3E6E5F',
        source: 'iOS App',
        confidence: 0.96,
        firstSeen: '2026-01-05T12:00:00Z',
        lastSeen: '2026-09-28T18:40:00Z'
      }
    ],
    identityGraph: {
      nodes: [
        { id: 'n1', label: 'marcus.vance@vanguardhq.com', type: 'email', source: 'Salesforce CRM', isPrimary: true, x: 260, y: 140 },
        { id: 'n2', label: 'nx_anon_7b99c01ff8a', type: 'anonymous_cookie', source: 'Web JS SDK', x: 120, y: 70 },
        { id: 'n3', label: '+1 (415) 890-2134', type: 'phone', source: 'Stripe Billing', x: 400, y: 80 },
        { id: 'n4', label: 'cus_Q98xLm01K99', type: 'stripe_customer_id', source: 'Stripe Billing', x: 380, y: 220 },
        { id: 'n5', label: 'SFDC: 0035G00002ab9X8QAA', type: 'crm_lead_id', source: 'Salesforce CRM', x: 130, y: 230 },
        { id: 'n6', label: 'IDFA: E621E1F8...6E5F', type: 'mobile_idfa', source: 'iOS App', x: 270, y: 280 }
      ],
      edges: [
        { id: 'e1', source: 'n2', target: 'n1', rule: 'Deterministic: Form Submission Email', confidence: 1.0, timestamp: '2025-11-14T08:32:00Z' },
        { id: 'e2', source: 'n1', target: 'n3', rule: 'Deterministic: Stripe Checkout Profile', confidence: 1.0, timestamp: '2025-11-18T10:15:00Z' },
        { id: 'e3', source: 'n3', target: 'n4', rule: 'Deterministic: Billing Customer Record', confidence: 1.0, timestamp: '2025-11-18T10:15:00Z' },
        { id: 'e4', source: 'n1', target: 'n5', rule: 'Deterministic: Exact Email Match CRM', confidence: 1.0, timestamp: '2025-11-14T08:32:00Z' },
        { id: 'e5', source: 'n1', target: 'n6', rule: 'Deterministic: App JWT Token Login', confidence: 0.99, timestamp: '2026-01-05T12:00:00Z' }
      ]
    },
    traits: {
      planTier: 'Enterprise Scale',
      seatsActive: 42,
      industry: 'B2B Publishing',
      annualContractValue: 24000,
      predictedNextOrderDays: 14,
      deviceBreakdown: 'macOS (64%), iOS (36%)'
    },
    segmentIds: ['seg_vip_spenders', 'seg_omnichannel'],
    recentEvents: [
      {
        id: 'ev_001',
        customerId: 'cust_01j7x8a901',
        name: 'Enterprise Dashboard Session',
        category: 'web',
        source: 'Web JS SDK',
        timestamp: '2026-09-28T18:45:00Z',
        properties: { url: '/analytics/q3-performance', durationSeconds: 420, referrer: 'direct' },
        identifiersSupplied: { cookie: 'nx_anon_7b99c01ff8a', email: 'marcus.vance@vanguardhq.com' }
      },
      {
        id: 'ev_002',
        customerId: 'cust_01j7x8a901',
        name: 'Invoice Payment Received',
        category: 'billing',
        source: 'Stripe',
        timestamp: '2026-09-18T09:30:00Z',
        properties: { amount: 2000, currency: 'USD', invoiceId: 'in_1P838a0982' },
        identifiersSupplied: { stripeId: 'cus_Q98xLm01K99', email: 'marcus.vance@vanguardhq.com' }
      },
      {
        id: 'ev_003',
        customerId: 'cust_01j7x8a901',
        name: 'Mobile App Push Opened',
        category: 'mobile',
        source: 'iOS App',
        timestamp: '2026-09-14T11:20:00Z',
        properties: { campaign: 'weekly_digest_v2', deepLink: 'nexus://reports/executive' },
        identifiersSupplied: { idfa: 'E621E1F8-C36C-495A-93FC-0C247A3E6E5F' }
      }
    ]
  },
  {
    id: 'cust_01j7x8a902',
    canonicalId: 'NX-901843',
    name: 'Elena Rostova',
    primaryEmail: 'elena.rostova@aurorafintech.co',
    primaryPhone: '+1 (212) 555-0199',
    company: 'Aurora FinTech',
    role: 'Head of Growth',
    avatarInitials: 'ER',
    lifecycleStage: 'At-Risk',
    ltv: 3450,
    orderCount: 4,
    avgOrderValue: 862,
    churnRisk: 86,
    npsScore: 4,
    rfmScore: { recency: 1, frequency: 3, monetary: 4 },
    firstSeenAt: '2026-02-10T11:20:00Z',
    lastActiveAt: '2026-09-02T14:15:00Z',
    country: 'United States',
    city: 'New York, NY',
    preferredChannel: 'Paid Social (Meta)',
    consent: {
      marketing: true,
      analytics: true,
      ccpaOptOut: false,
      gdprCompliant: true,
      updatedAt: '2026-05-12T09:10:00Z'
    },
    identifiers: [
      {
        id: 'id_201',
        type: 'email',
        value: 'elena.rostova@aurorafintech.co',
        source: 'Shopify',
        confidence: 1.0,
        firstSeen: '2026-02-10T11:20:00Z',
        lastSeen: '2026-09-02T14:15:00Z',
        isPrimary: true
      },
      {
        id: 'id_202',
        type: 'phone',
        value: '+12125550199',
        source: 'Shopify',
        confidence: 1.0,
        firstSeen: '2026-02-10T11:20:00Z',
        lastSeen: '2026-08-15T16:00:00Z'
      },
      {
        id: 'id_203',
        type: 'anonymous_cookie',
        value: 'nx_anon_91c01bfe41',
        source: 'Web JS SDK',
        confidence: 0.94,
        firstSeen: '2026-02-08T09:15:00Z',
        lastSeen: '2026-09-02T14:15:00Z'
      },
      {
        id: 'id_204',
        type: 'shopify_customer_id',
        value: 'sh_8129038102',
        source: 'Shopify',
        confidence: 1.0,
        firstSeen: '2026-02-10T11:20:00Z',
        lastSeen: '2026-08-15T16:00:00Z'
      }
    ],
    identityGraph: {
      nodes: [
        { id: 'en1', label: 'elena.rostova@aurorafintech.co', type: 'email', source: 'Shopify', isPrimary: true, x: 260, y: 130 },
        { id: 'en2', label: 'nx_anon_91c01bfe41', type: 'anonymous_cookie', source: 'Web JS SDK', x: 120, y: 100 },
        { id: 'en3', label: '+1 (212) 555-0199', type: 'phone', source: 'Shopify', x: 390, y: 100 },
        { id: 'en4', label: 'Shopify: 8129038102', type: 'shopify_customer_id', source: 'Shopify', x: 260, y: 240 }
      ],
      edges: [
        { id: 'ee1', source: 'en2', target: 'en1', rule: 'Deterministic: Cart Checkout Identification', confidence: 1.0, timestamp: '2026-02-10T11:20:00Z' },
        { id: 'ee2', source: 'en1', target: 'en3', rule: 'Deterministic: Shopify Order Profile', confidence: 1.0, timestamp: '2026-02-10T11:20:00Z' },
        { id: 'ee3', source: 'en1', target: 'en4', rule: 'Deterministic: Customer Object Creation', confidence: 1.0, timestamp: '2026-02-10T11:20:00Z' }
      ]
    },
    traits: {
      planTier: 'Pro Annual',
      supportTicketsTotal: 3,
      lastNpsScore: 4,
      daysSinceLastActivity: 26,
      churnTrigger: 'Support issue unaddressed regarding API latency'
    },
    segmentIds: ['seg_at_risk_churners', 'seg_winback_candidates'],
    recentEvents: [
      {
        id: 'ev_101',
        customerId: 'cust_01j7x8a902',
        name: 'Zendesk Ticket Raised: Urgent',
        category: 'crm',
        source: 'Zendesk',
        timestamp: '2026-09-02T14:15:00Z',
        properties: { ticketId: 'ZD-8812', subject: 'API Rate limit errors during billing run', sentiment: 'Frustrated' },
        identifiersSupplied: { email: 'elena.rostova@aurorafintech.co' }
      },
      {
        id: 'ev_102',
        customerId: 'cust_01j7x8a902',
        name: 'Account Settings Visited',
        category: 'web',
        source: 'Web JS SDK',
        timestamp: '2026-08-30T10:05:00Z',
        properties: { page: '/settings/billing/cancel-flow' },
        identifiersSupplied: { cookie: 'nx_anon_91c01bfe41' }
      }
    ]
  },
  {
    id: 'cust_01j7x8a903',
    canonicalId: 'NX-901844',
    name: 'Dev Patel',
    primaryEmail: 'dev.patel@horizon-ai.io',
    primaryPhone: '+1 (650) 412-9844',
    company: 'Horizon AI Labs',
    role: 'Founder & CEO',
    avatarInitials: 'DP',
    lifecycleStage: 'Free Trial',
    ltv: 0,
    orderCount: 0,
    avgOrderValue: 0,
    churnRisk: 42,
    npsScore: 8,
    rfmScore: { recency: 5, frequency: 2, monetary: 1 },
    firstSeenAt: '2026-09-24T14:20:00Z',
    lastActiveAt: '2026-09-28T21:10:00Z',
    country: 'United States',
    city: 'Palo Alto, CA',
    preferredChannel: 'Google Search',
    consent: {
      marketing: true,
      analytics: true,
      ccpaOptOut: false,
      gdprCompliant: true,
      updatedAt: '2026-09-24T14:20:00Z'
    },
    identifiers: [
      {
        id: 'id_301',
        type: 'email',
        value: 'dev.patel@horizon-ai.io',
        source: 'Web JS SDK',
        confidence: 1.0,
        firstSeen: '2026-09-24T14:20:00Z',
        lastSeen: '2026-09-28T21:10:00Z',
        isPrimary: true
      },
      {
        id: 'id_302',
        type: 'anonymous_cookie',
        value: 'nx_anon_30a9e710ff4',
        source: 'Web JS SDK',
        confidence: 0.99,
        firstSeen: '2026-09-20T08:15:00Z',
        lastSeen: '2026-09-28T21:10:00Z'
      },
      {
        id: 'id_303',
        type: 'phone',
        value: '+16504129844',
        source: 'Web JS SDK',
        confidence: 1.0,
        firstSeen: '2026-09-24T14:20:00Z',
        lastSeen: '2026-09-24T14:20:00Z'
      }
    ],
    identityGraph: {
      nodes: [
        { id: 'dn1', label: 'dev.patel@horizon-ai.io', type: 'email', source: 'Web JS SDK', isPrimary: true, x: 260, y: 150 },
        { id: 'dn2', label: 'nx_anon_30a9e710ff4', type: 'anonymous_cookie', source: 'Web JS SDK', x: 130, y: 110 },
        { id: 'dn3', label: '+1 (650) 412-9844', type: 'phone', source: 'Web JS SDK', x: 380, y: 190 }
      ],
      edges: [
        { id: 'de1', source: 'dn2', target: 'dn1', rule: 'Deterministic: Trial Sign-up Authentication', confidence: 1.0, timestamp: '2026-09-24T14:20:00Z' },
        { id: 'de2', source: 'dn1', target: 'dn3', rule: 'Deterministic: Phone Verification SMS', confidence: 1.0, timestamp: '2026-09-24T14:20:00Z' }
      ]
    },
    traits: {
      activeCartValue: 749,
      abandonedCart: true,
      pricingViewsLast7Days: 4,
      teamSizeEstimate: '20-50 employees'
    },
    segmentIds: ['seg_abandoned_cart_intent', 'seg_trial_converters'],
    recentEvents: [
      {
        id: 'ev_201',
        customerId: 'cust_01j7x8a903',
        name: 'Cart Abandoned (High Intent)',
        category: 'ecom',
        source: 'Shopify',
        timestamp: '2026-09-28T21:10:00Z',
        properties: { cartValue: 749, itemsCount: 2, planSelected: 'Scale Tier' },
        identifiersSupplied: { email: 'dev.patel@horizon-ai.io', cookie: 'nx_anon_30a9e710ff4' }
      },
      {
        id: 'ev_202',
        customerId: 'cust_01j7x8a903',
        name: 'Pricing Page Viewed',
        category: 'web',
        source: 'Web JS SDK',
        timestamp: '2026-09-28T20:55:00Z',
        properties: { utm_source: 'google_cpc', utm_campaign: 'b2b_competitor_switch' },
        identifiersSupplied: { cookie: 'nx_anon_30a9e710ff4' }
      }
    ]
  },
  {
    id: 'cust_01j7x8a904',
    canonicalId: 'NX-901845',
    name: 'Priya Sharma',
    primaryEmail: 'priya.sharma@luminafashion.com',
    primaryPhone: '+1 (312) 880-3321',
    company: 'Lumina Apparel',
    role: 'VP Ecommerce',
    avatarInitials: 'PS',
    lifecycleStage: 'Paying Customer',
    ltv: 2190,
    orderCount: 6,
    avgOrderValue: 365,
    churnRisk: 18,
    npsScore: 9,
    rfmScore: { recency: 4, frequency: 4, monetary: 3 },
    firstSeenAt: '2026-04-14T10:00:00Z',
    lastActiveAt: '2026-09-27T16:22:00Z',
    country: 'United States',
    city: 'Chicago, IL',
    preferredChannel: 'Paid Social (Meta)',
    consent: {
      marketing: true,
      analytics: true,
      ccpaOptOut: false,
      gdprCompliant: true,
      updatedAt: '2026-04-14T10:00:00Z'
    },
    identifiers: [
      {
        id: 'id_401',
        type: 'email',
        value: 'priya.sharma@luminafashion.com',
        source: 'Shopify',
        confidence: 1.0,
        firstSeen: '2026-04-14T10:00:00Z',
        lastSeen: '2026-09-27T16:22:00Z',
        isPrimary: true
      },
      {
        id: 'id_402',
        type: 'shopify_customer_id',
        value: 'sh_992104812',
        source: 'Shopify',
        confidence: 1.0,
        firstSeen: '2026-04-14T10:00:00Z',
        lastSeen: '2026-09-27T16:22:00Z'
      },
      {
        id: 'id_403',
        type: 'anonymous_cookie',
        value: 'nx_anon_9a820ffbb1',
        source: 'Web JS SDK',
        confidence: 0.97,
        firstSeen: '2026-04-10T12:00:00Z',
        lastSeen: '2026-09-27T16:22:00Z'
      }
    ],
    identityGraph: {
      nodes: [
        { id: 'pn1', label: 'priya.sharma@luminafashion.com', type: 'email', source: 'Shopify', isPrimary: true, x: 250, y: 130 },
        { id: 'pn2', label: 'nx_anon_9a820ffbb1', type: 'anonymous_cookie', source: 'Web JS SDK', x: 120, y: 160 },
        { id: 'pn3', label: 'Shopify: 992104812', type: 'shopify_customer_id', source: 'Shopify', x: 380, y: 140 }
      ],
      edges: [
        { id: 'pe1', source: 'pn2', target: 'pn1', rule: 'Deterministic: Order Checkout Completion', confidence: 1.0, timestamp: '2026-04-14T10:00:00Z' },
        { id: 'pe2', source: 'pn1', target: 'pn3', rule: 'Deterministic: Shopify Store Account', confidence: 1.0, timestamp: '2026-04-14T10:00:00Z' }
      ]
    },
    traits: {
      topCategory: 'Fall Collection',
      loyaltyTier: 'Gold Member',
      couponUsedCount: 3
    },
    segmentIds: ['seg_omnichannel'],
    recentEvents: [
      {
        id: 'ev_301',
        customerId: 'cust_01j7x8a904',
        name: 'Order Completed: $410',
        category: 'ecom',
        source: 'Shopify',
        timestamp: '2026-09-27T16:22:00Z',
        properties: { orderId: '#10892', items: 3, channel: 'Instagram Shop' },
        identifiersSupplied: { email: 'priya.sharma@luminafashion.com' }
      }
    ]
  },
  {
    id: 'cust_01j7x8a905',
    canonicalId: 'NX-901846',
    name: 'Anonymous Visitor #7819',
    primaryEmail: 'Unstitched (Anonymous)',
    primaryPhone: 'Unstitched',
    company: 'Unknown Organization',
    role: 'Web Visitor',
    avatarInitials: 'AN',
    lifecycleStage: 'Anonymous',
    ltv: 0,
    orderCount: 0,
    avgOrderValue: 0,
    churnRisk: 0,
    npsScore: 0,
    rfmScore: { recency: 5, frequency: 1, monetary: 1 },
    firstSeenAt: '2026-09-28T21:40:00Z',
    lastActiveAt: '2026-09-28T22:35:00Z',
    country: 'Germany',
    city: 'Munich',
    preferredChannel: 'Google Search',
    consent: {
      marketing: true,
      analytics: true,
      ccpaOptOut: false,
      gdprCompliant: true,
      updatedAt: '2026-09-28T21:40:00Z'
    },
    identifiers: [
      {
        id: 'id_501',
        type: 'anonymous_cookie',
        value: 'nx_anon_98f12aae8802',
        source: 'Web JS SDK',
        confidence: 1.0,
        firstSeen: '2026-09-28T21:40:00Z',
        lastSeen: '2026-09-28T22:35:00Z',
        isPrimary: true
      }
    ],
    identityGraph: {
      nodes: [
        { id: 'an1', label: 'nx_anon_98f12aae8802', type: 'anonymous_cookie', source: 'Web JS SDK', isPrimary: true, x: 260, y: 150 }
      ],
      edges: []
    },
    traits: {
      pageviewsCurrentSession: 7,
      visitedEnterpriseSecurityPage: true,
      ipSubnet: '178.62.x.x',
      operatingSystem: 'Ubuntu Linux 24.04',
      browser: 'Chrome 130'
    },
    segmentIds: [],
    recentEvents: [
      {
        id: 'ev_401',
        customerId: 'cust_01j7x8a905',
        name: 'Enterprise Security Pageview',
        category: 'web',
        source: 'Web JS SDK',
        timestamp: '2026-09-28T22:35:00Z',
        properties: { url: '/security/soc2-iso27001', dwellSeconds: 190 },
        identifiersSupplied: { cookie: 'nx_anon_98f12aae8802' }
      }
    ]
  },
  {
    id: 'cust_01j7x8a906',
    canonicalId: 'NX-901847',
    name: 'Jordan Blake',
    primaryEmail: 'jordan.blake@vertex-cloud.net',
    primaryPhone: '+1 (512) 991-4402',
    company: 'Vertex Cloud',
    role: 'VP Infrastructure',
    avatarInitials: 'JB',
    lifecycleStage: 'At-Risk',
    ltv: 8200,
    orderCount: 11,
    avgOrderValue: 745,
    churnRisk: 74,
    npsScore: 6,
    rfmScore: { recency: 2, frequency: 4, monetary: 5 },
    firstSeenAt: '2025-08-20T10:00:00Z',
    lastActiveAt: '2026-08-10T14:30:00Z',
    country: 'United States',
    city: 'Austin, TX',
    preferredChannel: 'Email',
    consent: {
      marketing: true,
      analytics: true,
      ccpaOptOut: false,
      gdprCompliant: true,
      updatedAt: '2025-08-20T10:00:00Z'
    },
    identifiers: [
      {
        id: 'id_601',
        type: 'email',
        value: 'jordan.blake@vertex-cloud.net',
        source: 'Salesforce CRM',
        confidence: 1.0,
        firstSeen: '2025-08-20T10:00:00Z',
        lastSeen: '2026-08-10T14:30:00Z',
        isPrimary: true
      },
      {
        id: 'id_602',
        type: 'phone',
        value: '+15129914402',
        source: 'Salesforce CRM',
        confidence: 1.0,
        firstSeen: '2025-08-20T10:00:00Z',
        lastSeen: '2026-08-10T14:30:00Z'
      },
      {
        id: 'id_603',
        type: 'stripe_customer_id',
        value: 'cus_JB881902K',
        source: 'Stripe Billing',
        confidence: 1.0,
        firstSeen: '2025-09-01T12:00:00Z',
        lastSeen: '2026-08-01T10:00:00Z'
      }
    ],
    identityGraph: {
      nodes: [
        { id: 'jn1', label: 'jordan.blake@vertex-cloud.net', type: 'email', source: 'Salesforce CRM', isPrimary: true, x: 260, y: 140 },
        { id: 'jn2', label: '+1 (512) 991-4402', type: 'phone', source: 'Salesforce CRM', x: 130, y: 160 },
        { id: 'jn3', label: 'cus_JB881902K', type: 'stripe_customer_id', source: 'Stripe Billing', x: 390, y: 150 }
      ],
      edges: [
        { id: 'je1', source: 'jn2', target: 'jn1', rule: 'Deterministic: CRM Contact Record', confidence: 1.0, timestamp: '2025-08-20T10:00:00Z' },
        { id: 'je2', source: 'jn1', target: 'jn3', rule: 'Deterministic: Invoice Email Match', confidence: 1.0, timestamp: '2025-09-01T12:00:00Z' }
      ]
    },
    traits: {
      lastQuarterUsageDrop: '45% decline',
      daysInactive: 49,
      contractRenewalDate: '2026-11-01'
    },
    segmentIds: ['seg_at_risk_churners', 'seg_winback_candidates', 'seg_vip_spenders'],
    recentEvents: [
      {
        id: 'ev_501',
        customerId: 'cust_01j7x8a906',
        name: 'Email Newsletter Opened',
        category: 'marketing',
        source: 'Salesforce CRM',
        timestamp: '2026-08-10T14:30:00Z',
        properties: { campaign: 'monthly_digest_august' },
        identifiersSupplied: { email: 'jordan.blake@vertex-cloud.net' }
      }
    ]
  }
];

export const INITIAL_SEGMENTS: Segment[] = [
  {
    id: 'seg_vip_spenders',
    name: 'VIP High-LTV Accounts ($2,500+)',
    description: 'Top-tier customers with lifetime value exceeding $2,500 and high brand affinity.',
    category: 'High Value',
    rules: {
      combinator: 'AND',
      rules: [
        { id: 'r1', field: 'ltv', operator: 'greater_than', value: 2500 },
        { id: 'r2', field: 'orderCount', operator: 'greater_than', value: 2 }
      ]
    },
    profileCount: 3,
    matchRatePercent: 82.5,
    lastCalculated: '2026-09-28T22:30:00Z',
    syncDestinations: ['dest_google_ads', 'dest_meta_ads', 'dest_klaviyo'],
    status: 'active',
    projectedRoas: 4.8
  },
  {
    id: 'seg_at_risk_churners',
    name: 'High-Value At-Risk Churners',
    description: 'Customers with LTV > $1,000 who exhibit churn risk score >= 60% or logged high-sentiment support issues.',
    category: 'Retention',
    rules: {
      combinator: 'AND',
      rules: [
        { id: 'r3', field: 'ltv', operator: 'greater_than', value: 1000 },
        { id: 'r4', field: 'churnRisk', operator: 'greater_than', value: 60 }
      ]
    },
    profileCount: 2,
    matchRatePercent: 78.4,
    lastCalculated: '2026-09-28T22:30:00Z',
    syncDestinations: ['dest_meta_ads', 'dest_klaviyo', 'dest_braze'],
    status: 'active',
    projectedRoas: 3.9
  },
  {
    id: 'seg_abandoned_cart_intent',
    name: 'High-Intent Cart Abandoners ($500+)',
    description: 'Visitors and trial users with cart value above $500 abandoned within 72 hours.',
    category: 'Acquisition',
    rules: {
      combinator: 'AND',
      rules: [
        { id: 'r5', field: 'traits.activeCartValue', operator: 'greater_than', value: 500 },
        { id: 'r6', field: 'consent.marketing', operator: 'equals', value: true }
      ]
    },
    profileCount: 1,
    matchRatePercent: 88.0,
    lastCalculated: '2026-09-28T22:30:00Z',
    syncDestinations: ['dest_google_ads', 'dest_meta_ads', 'dest_tiktok_ads'],
    status: 'active',
    projectedRoas: 5.6
  },
  {
    id: 'seg_winback_candidates',
    name: 'Dormant Winback Candidates',
    description: 'Previously frequent customers who have not had an active session in 20+ days.',
    category: 'Winback',
    rules: {
      combinator: 'AND',
      rules: [
        { id: 'r7', field: 'churnRisk', operator: 'greater_than', value: 50 }
      ]
    },
    profileCount: 2,
    matchRatePercent: 74.2,
    lastCalculated: '2026-09-28T22:30:00Z',
    syncDestinations: ['dest_google_ads', 'dest_klaviyo'],
    status: 'active',
    projectedRoas: 3.2
  },
  {
    id: 'seg_omnichannel',
    name: 'Omnichannel Stitched Buyers',
    description: 'Profiles with 3 or more resolved identifier nodes across web, mobile, and CRM.',
    category: 'Engagement',
    rules: {
      combinator: 'AND',
      rules: [
        { id: 'r8', field: 'identifiers.length', operator: 'greater_than', value: 2 }
      ]
    },
    profileCount: 3,
    matchRatePercent: 91.2,
    lastCalculated: '2026-09-28T22:30:00Z',
    syncDestinations: ['dest_google_ads', 'dest_meta_ads', 'dest_linkedin_ads'],
    status: 'active',
    projectedRoas: 4.4
  }
];

export const INITIAL_DESTINATIONS: Destination[] = [
  {
    id: 'dest_google_ads',
    name: 'Google Ads Customer Match',
    category: 'ad_platform',
    icon: 'Search',
    status: 'connected',
    syncFrequency: 'realtime',
    hashingAlgorithm: 'SHA-256',
    matchRateBenchmark: 81.4,
    activeAudiencesCount: 4,
    totalSyncedProfiles: 42910,
    supportedIdentifiers: ['email (sha256)', 'phone (e.164 sha256)', 'first_name', 'last_name', 'postal_code', 'country'],
    lastSyncAt: '2026-09-28T22:15:00Z',
    lastSyncStatus: 'success'
  },
  {
    id: 'dest_meta_ads',
    name: 'Meta Ads (Facebook & IG Audiences)',
    category: 'ad_platform',
    icon: 'Share2',
    status: 'connected',
    syncFrequency: 'realtime',
    hashingAlgorithm: 'SHA-256',
    matchRateBenchmark: 79.2,
    activeAudiencesCount: 4,
    totalSyncedProfiles: 38400,
    supportedIdentifiers: ['email (sha256)', 'phone (sha256)', 'madid / idfa', 'external_id'],
    lastSyncAt: '2026-09-28T22:18:00Z',
    lastSyncStatus: 'success'
  },
  {
    id: 'dest_tiktok_ads',
    name: 'TikTok Ads Audience Manager',
    category: 'ad_platform',
    icon: 'Video',
    status: 'connected',
    syncFrequency: '1h',
    hashingAlgorithm: 'SHA-256',
    matchRateBenchmark: 68.6,
    activeAudiencesCount: 2,
    totalSyncedProfiles: 18240,
    supportedIdentifiers: ['email (sha256)', 'phone (sha256)', 'idfa', 'gaid'],
    lastSyncAt: '2026-09-28T21:30:00Z',
    lastSyncStatus: 'success'
  },
  {
    id: 'dest_linkedin_ads',
    name: 'LinkedIn Matched Audiences',
    category: 'ad_platform',
    icon: 'Briefcase',
    status: 'connected',
    syncFrequency: '24h',
    hashingAlgorithm: 'SHA-256',
    matchRateBenchmark: 73.8,
    activeAudiencesCount: 2,
    totalSyncedProfiles: 12500,
    supportedIdentifiers: ['work_email (sha256)', 'company_name', 'job_title'],
    lastSyncAt: '2026-09-28T04:00:00Z',
    lastSyncStatus: 'success'
  },
  {
    id: 'dest_klaviyo',
    name: 'Klaviyo Marketing Automation',
    category: 'marketing_cloud',
    icon: 'Mail',
    status: 'connected',
    syncFrequency: 'realtime',
    hashingAlgorithm: 'Plaintext (Encrypted)',
    matchRateBenchmark: 95.8,
    activeAudiencesCount: 4,
    totalSyncedProfiles: 51200,
    supportedIdentifiers: ['email', 'phone', 'first_name', 'last_name', 'custom_properties'],
    lastSyncAt: '2026-09-28T22:25:00Z',
    lastSyncStatus: 'success'
  },
  {
    id: 'dest_braze',
    name: 'Braze Mobile & Cross-Channel',
    category: 'marketing_cloud',
    icon: 'Bell',
    status: 'connected',
    syncFrequency: 'realtime',
    hashingAlgorithm: 'Plaintext (Encrypted)',
    matchRateBenchmark: 92.4,
    activeAudiencesCount: 2,
    totalSyncedProfiles: 29800,
    supportedIdentifiers: ['external_id', 'email', 'phone', 'push_tokens'],
    lastSyncAt: '2026-09-28T22:00:00Z',
    lastSyncStatus: 'success'
  }
];

export const INITIAL_SYNC_LOGS: SyncExecutionLog[] = [
  {
    id: 'log_901',
    destinationId: 'dest_google_ads',
    destinationName: 'Google Ads Customer Match',
    segmentId: 'seg_vip_spenders',
    segmentName: 'VIP High-LTV Accounts ($2,500+)',
    timestamp: '2026-09-28T22:15:00Z',
    profilesPushed: 1420,
    profilesMatched: 1162,
    matchRate: 81.8,
    latencyMs: 380,
    status: 'success',
    sampleHashedPayload: 'SHA256(marcus.vance@...)=4f9d8a11b6... | Country: US'
  },
  {
    id: 'log_902',
    destinationId: 'dest_meta_ads',
    destinationName: 'Meta Ads Custom Audiences',
    segmentId: 'seg_at_risk_churners',
    segmentName: 'High-Value At-Risk Churners',
    timestamp: '2026-09-28T22:18:00Z',
    profilesPushed: 890,
    profilesMatched: 708,
    matchRate: 79.5,
    latencyMs: 420,
    status: 'success',
    sampleHashedPayload: 'EXT_ID: NX-901843 | SHA256(elena.rostova@...)'
  },
  {
    id: 'log_903',
    destinationId: 'dest_klaviyo',
    destinationName: 'Klaviyo Marketing Automation',
    segmentId: 'seg_abandoned_cart_intent',
    segmentName: 'High-Intent Cart Abandoners ($500+)',
    timestamp: '2026-09-28T22:25:00Z',
    profilesPushed: 412,
    profilesMatched: 395,
    matchRate: 95.8,
    latencyMs: 195,
    status: 'success',
    sampleHashedPayload: 'email: dev.patel@horizon-ai.io | cartValue: $749'
  },
  {
    id: 'log_904',
    destinationId: 'dest_tiktok_ads',
    destinationName: 'TikTok Ads Audience Manager',
    segmentId: 'seg_abandoned_cart_intent',
    segmentName: 'High-Intent Cart Abandoners ($500+)',
    timestamp: '2026-09-28T21:30:00Z',
    profilesPushed: 412,
    profilesMatched: 283,
    matchRate: 68.7,
    latencyMs: 510,
    status: 'success',
    sampleHashedPayload: 'SHA256(phone)=81b0a99ff... | GAID'
  }
];

export const INITIAL_DATA_SOURCES: DataSource[] = [
  {
    id: 'src_web',
    name: 'Web JavaScript SDK',
    categoryName: 'Client-Side Analytics',
    type: 'client_sdk',
    status: 'streaming',
    eventsPerSec: 142,
    totalEvents24h: 3892000,
    lastEventReceived: '2026-09-28T22:45:00Z',
    schemaFieldsCount: 28
  },
  {
    id: 'src_shopify',
    name: 'Shopify Storefront & Orders',
    categoryName: 'E-Commerce Platform',
    type: 'ecom',
    status: 'streaming',
    eventsPerSec: 34,
    totalEvents24h: 842000,
    lastEventReceived: '2026-09-28T22:44:50Z',
    schemaFieldsCount: 44
  },
  {
    id: 'src_mobile',
    name: 'iOS & Android SDK',
    categoryName: 'Native Mobile Apps',
    type: 'mobile_sdk',
    status: 'streaming',
    eventsPerSec: 68,
    totalEvents24h: 1920000,
    lastEventReceived: '2026-09-28T22:44:58Z',
    schemaFieldsCount: 32
  },
  {
    id: 'src_salesforce',
    name: 'Salesforce Sales Cloud CRM',
    categoryName: 'B2B CRM & Pipeline',
    type: 'crm',
    status: 'healthy',
    eventsPerSec: 12,
    totalEvents24h: 215000,
    lastEventReceived: '2026-09-28T22:43:10Z',
    schemaFieldsCount: 65
  },
  {
    id: 'src_stripe',
    name: 'Stripe Billing & Subscriptions',
    categoryName: 'Payments & Revenue',
    type: 'billing',
    status: 'streaming',
    eventsPerSec: 18,
    totalEvents24h: 412000,
    lastEventReceived: '2026-09-28T22:44:12Z',
    schemaFieldsCount: 22
  },
  {
    id: 'src_snowflake',
    name: 'Snowflake Enterprise Warehouse',
    categoryName: 'Reverse ETL & Models',
    type: 'warehouse',
    status: 'healthy',
    eventsPerSec: 0,
    totalEvents24h: 120000,
    lastEventReceived: '2026-09-28T22:00:00Z',
    schemaFieldsCount: 54
  }
];

export const INITIAL_LIVE_EVENTS: CustomerEvent[] = [
  {
    id: 'live_ev_101',
    customerId: 'cust_01j7x8a901',
    name: 'Session Heartbeat Active',
    category: 'web',
    source: 'Web JS SDK',
    timestamp: '2026-09-28T22:46:12Z',
    properties: { path: '/executive-summary', scrollDepth: '85%' },
    identifiersSupplied: { cookie: 'nx_anon_7b99c01ff8a', email: 'marcus.vance@vanguardhq.com' }
  },
  {
    id: 'live_ev_102',
    customerId: 'cust_01j7x8a903',
    name: 'Checkout Step 2 (Payment Form)',
    category: 'ecom',
    source: 'Shopify',
    timestamp: '2026-09-28T22:44:50Z',
    properties: { step: 'payment_methods', cartTotal: 749, discountApplied: 'SCALE20' },
    identifiersSupplied: { email: 'dev.patel@horizon-ai.io' }
  },
  {
    id: 'live_ev_103',
    customerId: 'cust_01j7x8a905',
    name: 'Compliance Page View',
    category: 'web',
    source: 'Web JS SDK',
    timestamp: '2026-09-28T22:43:18Z',
    properties: { page: '/trust-center/iso-27001' },
    identifiersSupplied: { cookie: 'nx_anon_98f12aae8802' }
  },
  {
    id: 'live_ev_104',
    customerId: 'cust_01j7x8a904',
    name: 'Product Catalog Viewed',
    category: 'web',
    source: 'Web JS SDK',
    timestamp: '2026-09-28T22:40:05Z',
    properties: { category: 'Autumn Knitwear', itemsVisible: 24 },
    identifiersSupplied: { email: 'priya.sharma@luminafashion.com' }
  }
];

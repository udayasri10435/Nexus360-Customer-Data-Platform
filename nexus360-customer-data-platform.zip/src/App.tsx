import React from 'react';
import { CDPProvider, useCDP } from './context/CDPContext';
import Header from './components/layout/Header';
import CustomerList from './components/customer360/CustomerList';
import CustomerDetailView from './components/customer360/CustomerDetailView';
import IdentityGraphViewer from './components/identity/IdentityGraphViewer';
import SegmentBuilder from './components/segments/SegmentBuilder';
import ActivationHub from './components/activation/ActivationHub';
import EventIngestionStream from './components/events/EventIngestionStream';
import SourcesCatalog from './components/sources/SourcesCatalog';

const MainContent: React.FC = () => {
  const { currentView, setCurrentView, selectedCustomer, selectedCustomerId, setSelectedCustomerId } = useCDP();

  return (
    <main className="flex-1 flex flex-col overflow-hidden">
      {currentView === 'customer360' && (
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Customer Directory Master Column */}
          <div className="w-full md:w-80 lg:w-96 h-full shrink-0">
            <CustomerList
              onSelectCustomer={(id) => setSelectedCustomerId(id)}
              selectedId={selectedCustomerId}
            />
          </div>

          {/* Customer 360 Detail View */}
          <div className="flex-1 h-full overflow-hidden bg-slate-950">
            {selectedCustomer ? (
              <CustomerDetailView
                customer={selectedCustomer}
                onOpenGraphView={() => setCurrentView('identity_graph')}
              />
            ) : (
              <div className="flex items-center justify-center h-full p-8 text-slate-500 text-xs">
                Select a customer profile to inspect their unified Customer 360 view.
              </div>
            )}
          </div>
        </div>
      )}

      {currentView === 'identity_graph' && (
        <IdentityGraphViewer />
      )}

      {currentView === 'segments' && (
        <SegmentBuilder />
      )}

      {currentView === 'activation' && (
        <ActivationHub />
      )}

      {currentView === 'events' && (
        <EventIngestionStream />
      )}

      {currentView === 'sources' && (
        <SourcesCatalog />
      )}
    </main>
  );
};

export default function App() {
  return (
    <CDPProvider>
      <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 text-slate-100">
        <Header />
        <MainContent />
      </div>
    </CDPProvider>
  );
}

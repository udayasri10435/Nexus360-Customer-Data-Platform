import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  CustomerProfile,
  Segment,
  Destination,
  SyncExecutionLog,
  DataSource,
  CustomerEvent,
  GraphNode,
  GraphEdge
} from '../types/cdp';
import {
  INITIAL_CUSTOMERS,
  INITIAL_SEGMENTS,
  INITIAL_DESTINATIONS,
  INITIAL_SYNC_LOGS,
  INITIAL_DATA_SOURCES,
  INITIAL_LIVE_EVENTS
} from '../data/initialData';

export type CDPView = 
  | 'customer360'
  | 'identity_graph'
  | 'segments'
  | 'activation'
  | 'events'
  | 'sources';

interface CDPContextType {
  currentView: CDPView;
  setCurrentView: (view: CDPView) => void;
  customers: CustomerProfile[];
  selectedCustomer: CustomerProfile | null;
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;
  segments: Segment[];
  destinations: Destination[];
  dataSources: DataSource[];
  syncLogs: SyncExecutionLog[];
  liveEvents: CustomerEvent[];
  isAutoStreaming: boolean;
  toggleAutoStream: () => void;
  isSyncingGlobal: boolean;
  
  // Actions
  ingestEvent: (eventData: {
    customerId?: string;
    name: string;
    category: CustomerEvent['category'];
    source: CustomerEvent['source'];
    properties: Record<string, any>;
    identifiersSupplied: Record<string, string>;
  }) => void;
  stitchIdentities: (
    sourceCustomerId: string,
    targetCustomerId: string,
    matchRule: string,
    confidence: number
  ) => void;
  createSegment: (newSeg: Omit<Segment, 'id' | 'profileCount' | 'matchRatePercent' | 'lastCalculated'>) => void;
  updateSegment: (id: string, updates: Partial<Segment>) => void;
  deleteSegment: (id: string) => void;
  triggerSync: (segmentId: string, destinationId?: string) => Promise<void>;
  syncAllAudiences: () => Promise<void>;
  toggleDestinationStatus: (destinationId: string) => void;
  updateDestinationFrequency: (destinationId: string, freq: Destination['syncFrequency']) => void;
}

const CDPContext = createContext<CDPContextType | undefined>(undefined);

export const CDPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<CDPView>('customer360');
  const [customers, setCustomers] = useState<CustomerProfile[]>(() => {
    const saved = localStorage.getItem('nexus_cdp_customers');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>('cust_01j7x8a901');
  const [segments, setSegments] = useState<Segment[]>(() => {
    const saved = localStorage.getItem('nexus_cdp_segments');
    return saved ? JSON.parse(saved) : INITIAL_SEGMENTS;
  });
  const [destinations, setDestinations] = useState<Destination[]>(() => {
    const saved = localStorage.getItem('nexus_cdp_destinations');
    return saved ? JSON.parse(saved) : INITIAL_DESTINATIONS;
  });
  const [dataSources] = useState<DataSource[]>(INITIAL_DATA_SOURCES);
  const [syncLogs, setSyncLogs] = useState<SyncExecutionLog[]>(() => {
    const saved = localStorage.getItem('nexus_cdp_sync_logs');
    return saved ? JSON.parse(saved) : INITIAL_SYNC_LOGS;
  });
  const [liveEvents, setLiveEvents] = useState<CustomerEvent[]>(INITIAL_LIVE_EVENTS);
  const [isAutoStreaming, setIsAutoStreaming] = useState(false);
  const [isSyncingGlobal, setIsSyncingGlobal] = useState(false);

  // Sync state to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('nexus_cdp_customers', JSON.stringify(customers));
    } catch {
      // quota or private mode safe
    }
  }, [customers]);

  useEffect(() => {
    try {
      localStorage.setItem('nexus_cdp_segments', JSON.stringify(segments));
    } catch {}
  }, [segments]);

  useEffect(() => {
    try {
      localStorage.setItem('nexus_cdp_destinations', JSON.stringify(destinations));
    } catch {}
  }, [destinations]);

  useEffect(() => {
    try {
      localStorage.setItem('nexus_cdp_sync_logs', JSON.stringify(syncLogs));
    } catch {}
  }, [syncLogs]);

  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === selectedCustomerId) || null;
  }, [customers, selectedCustomerId]);

  // Dynamic Rule Evaluator for segments
  const evaluateSegmentMatches = useCallback((segList: Segment[], custs: CustomerProfile[]) => {
    return segList.map(segment => {
      const matchingCount = custs.filter(cust => {
        const { rules, combinator } = segment.rules;
        if (!rules || rules.length === 0) return true;

        const results = rules.map(rule => {
          let targetVal: any;
          if (rule.field.startsWith('traits.')) {
            const traitKey = rule.field.replace('traits.', '');
            targetVal = cust.traits?.[traitKey];
          } else if (rule.field.startsWith('consent.')) {
            const consentKey = rule.field.replace('consent.', '');
            targetVal = (cust.consent as any)?.[consentKey];
          } else if (rule.field === 'identifiers.length') {
            targetVal = cust.identifiers?.length || 0;
          } else {
            targetVal = (cust as any)[rule.field];
          }

          if (targetVal === undefined || targetVal === null) return false;

          switch (rule.operator) {
            case 'greater_than':
              return Number(targetVal) > Number(rule.value);
            case 'less_than':
              return Number(targetVal) < Number(rule.value);
            case 'equals':
              return String(targetVal).toLowerCase() === String(rule.value).toLowerCase();
            case 'not_equals':
              return String(targetVal).toLowerCase() !== String(rule.value).toLowerCase();
            case 'contains':
              return String(targetVal).toLowerCase().includes(String(rule.value).toLowerCase());
            default:
              return true;
          }
        });

        return combinator === 'OR' ? results.some(Boolean) : results.every(Boolean);
      }).length;

      const pct = custs.length > 0 ? Math.round((matchingCount / custs.length) * 100) : 0;
      return {
        ...segment,
        profileCount: matchingCount,
        matchRatePercent: pct,
        lastCalculated: new Date().toISOString()
      };
    });
  }, []);

  // Stitch Identities Function
  const stitchIdentities = useCallback((
    sourceCustomerId: string,
    targetCustomerId: string,
    matchRule: string,
    confidence: number
  ) => {
    setCustomers(prev => {
      const sourceCust = prev.find(c => c.id === sourceCustomerId);
      const targetCust = prev.find(c => c.id === targetCustomerId);
      if (!sourceCust || !targetCust || sourceCust.id === targetCust.id) return prev;

      // Merge identifiers
      const combinedIdentifiers = [...targetCust.identifiers];
      sourceCust.identifiers.forEach(srcId => {
        if (!combinedIdentifiers.some(t => t.value === srcId.value)) {
          combinedIdentifiers.push({
            ...srcId,
            confidence: Math.min(srcId.confidence, confidence)
          });
        }
      });

      // Merge nodes & add edge
      const targetNodes = [...targetCust.identityGraph.nodes];
      const targetEdges = [...targetCust.identityGraph.edges];

      // Add nodes from source that don't exist
      sourceCust.identityGraph.nodes.forEach(srcNode => {
        if (!targetNodes.some(n => n.label === srcNode.label)) {
          targetNodes.push({
            ...srcNode,
            id: `merged_${srcNode.id}_${Date.now()}`,
            isPrimary: false,
            x: (srcNode.x || 200) + 40,
            y: (srcNode.y || 150) + 40
          });
        }
      });

      // Add connecting edge
      const primaryTargetNode = targetNodes.find(n => n.isPrimary) || targetNodes[0];
      const addedNode = targetNodes.find(n => n.label === sourceCust.identifiers[0]?.value) || targetNodes[targetNodes.length - 1];
      
      if (primaryTargetNode && addedNode && primaryTargetNode.id !== addedNode.id) {
        targetEdges.push({
          id: `edge_stitch_${Date.now()}`,
          source: addedNode.id,
          target: primaryTargetNode.id,
          rule: matchRule,
          confidence,
          timestamp: new Date().toISOString()
        });
      }

      // Updated target customer
      const updatedTarget: CustomerProfile = {
        ...targetCust,
        ltv: targetCust.ltv + sourceCust.ltv,
        orderCount: targetCust.orderCount + sourceCust.orderCount,
        identifiers: combinedIdentifiers,
        identityGraph: {
          nodes: targetNodes,
          edges: targetEdges
        },
        traits: {
          ...sourceCust.traits,
          ...targetCust.traits,
          stitchedProfilesCount: ((targetCust.traits.stitchedProfilesCount as number) || 1) + 1
        },
        recentEvents: [...sourceCust.recentEvents, ...targetCust.recentEvents].slice(0, 15),
        lastActiveAt: new Date().toISOString()
      };

      // Remove source customer, update target
      const filtered = prev.filter(c => c.id !== sourceCustomerId).map(c => c.id === targetCustomerId ? updatedTarget : c);
      return filtered;
    });

    // Ingest synthetic stitch event
    const stitchEvent: CustomerEvent = {
      id: `ev_stitch_${Date.now()}`,
      customerId: targetCustomerId,
      name: 'Identity Stitched: Graph Merged',
      category: 'crm',
      source: 'Web JS SDK',
      timestamp: new Date().toISOString(),
      properties: { rule: matchRule, confidence, sourceCustomerId },
      identifiersSupplied: { matchRule }
    };
    setLiveEvents(prev => [stitchEvent, ...prev.slice(0, 40)]);
  }, []);

  // Ingest Event Engine
  const ingestEvent = useCallback((eventData: {
    customerId?: string;
    name: string;
    category: CustomerEvent['category'];
    source: CustomerEvent['source'];
    properties: Record<string, any>;
    identifiersSupplied: Record<string, string>;
  }) => {
    const timestamp = new Date().toISOString();
    const eventId = `ev_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    // Resolve or find customer
    setCustomers(prev => {
      let targetCust: CustomerProfile | undefined;

      // 1. Try matching by explicit customerId
      if (eventData.customerId) {
        targetCust = prev.find(c => c.id === eventData.customerId);
      }

      // 2. Try matching by email
      const suppliedEmail = eventData.identifiersSupplied.email;
      if (!targetCust && suppliedEmail) {
        targetCust = prev.find(c => 
          c.primaryEmail.toLowerCase() === suppliedEmail.toLowerCase() ||
          c.identifiers.some(id => id.type === 'email' && id.value.toLowerCase() === suppliedEmail.toLowerCase())
        );
      }

      // 3. Try matching by cookie
      const suppliedCookie = eventData.identifiersSupplied.cookie;
      if (!targetCust && suppliedCookie) {
        targetCust = prev.find(c =>
          c.identifiers.some(id => id.type === 'anonymous_cookie' && id.value === suppliedCookie)
        );
      }

      // 4. Try matching by phone
      const suppliedPhone = eventData.identifiersSupplied.phone;
      if (!targetCust && suppliedPhone) {
        targetCust = prev.find(c =>
          c.identifiers.some(id => id.type === 'phone' && id.value.replace(/\D/g, '') === suppliedPhone.replace(/\D/g, ''))
        );
      }

      // If customer found, update them
      if (targetCust) {
        const fullEvent: CustomerEvent = {
          id: eventId,
          customerId: targetCust.id,
          name: eventData.name,
          category: eventData.category,
          source: eventData.source,
          timestamp,
          properties: eventData.properties,
          identifiersSupplied: eventData.identifiersSupplied
        };

        // Check if event introduced a new identifier to stitch!
        const updatedIdentifiers = [...targetCust.identifiers];
        const updatedNodes = [...targetCust.identityGraph.nodes];
        const updatedEdges = [...targetCust.identityGraph.edges];

        if (suppliedEmail && !updatedIdentifiers.some(i => i.value.toLowerCase() === suppliedEmail.toLowerCase())) {
          updatedIdentifiers.push({
            id: `id_auto_${Date.now()}`,
            type: 'email',
            value: suppliedEmail,
            source: eventData.source,
            confidence: 1.0,
            firstSeen: timestamp,
            lastSeen: timestamp
          });
          const newNode: GraphNode = {
            id: `node_email_${Date.now()}`,
            label: suppliedEmail,
            type: 'email',
            source: eventData.source,
            x: 240,
            y: 90
          };
          updatedNodes.push(newNode);
          const primary = updatedNodes.find(n => n.isPrimary) || updatedNodes[0];
          if (primary && primary.id !== newNode.id) {
            updatedEdges.push({
              id: `edge_${Date.now()}`,
              source: newNode.id,
              target: primary.id,
              rule: 'Deterministic: Supplied Ingestion Event',
              confidence: 1.0,
              timestamp
            });
          }
        }

        // LTV adjustments if purchase event
        let newLtv = targetCust.ltv;
        let newOrderCount = targetCust.orderCount;
        if (eventData.properties.amount || eventData.properties.cartTotal) {
          const added = Number(eventData.properties.amount || eventData.properties.cartTotal || 0);
          newLtv += added;
          newOrderCount += 1;
        }

        // Churn risk adjustment if support ticket or complaint
        let newChurnRisk = targetCust.churnRisk;
        if (eventData.name.toLowerCase().includes('ticket') || eventData.name.toLowerCase().includes('complaint')) {
          newChurnRisk = Math.min(100, newChurnRisk + 25);
        } else if (eventData.name.toLowerCase().includes('order') || eventData.name.toLowerCase().includes('renewed')) {
          newChurnRisk = Math.max(5, newChurnRisk - 15);
        }

        const updatedCust: CustomerProfile = {
          ...targetCust,
          ltv: newLtv,
          orderCount: newOrderCount,
          churnRisk: newChurnRisk,
          lastActiveAt: timestamp,
          identifiers: updatedIdentifiers,
          identityGraph: {
            nodes: updatedNodes,
            edges: updatedEdges
          },
          recentEvents: [fullEvent, ...targetCust.recentEvents.slice(0, 19)]
        };

        return prev.map(c => c.id === targetCust?.id ? updatedCust : c);
      }

      // If no customer matched, create new Anonymous or Lead profile!
      const newCustId = `cust_gen_${Date.now()}`;
      const isLead = Boolean(suppliedEmail);
      const newProfile: CustomerProfile = {
        id: newCustId,
        canonicalId: `NX-${Math.floor(100000 + Math.random() * 900000)}`,
        name: isLead ? suppliedEmail!.split('@')[0] : `Anonymous Visitor #${Math.floor(1000 + Math.random() * 9000)}`,
        primaryEmail: suppliedEmail || 'Unstitched (Anonymous)',
        primaryPhone: suppliedPhone || 'Unstitched',
        avatarInitials: isLead ? suppliedEmail!.substring(0, 2).toUpperCase() : 'AN',
        lifecycleStage: isLead ? 'Lead' : 'Anonymous',
        ltv: Number(eventData.properties.amount || 0),
        orderCount: eventData.properties.amount ? 1 : 0,
        avgOrderValue: Number(eventData.properties.amount || 0),
        churnRisk: 15,
        npsScore: 0,
        rfmScore: { recency: 5, frequency: 1, monetary: 1 },
        firstSeenAt: timestamp,
        lastActiveAt: timestamp,
        country: 'United States',
        city: 'Unknown Location',
        preferredChannel: 'Paid Social (Meta)',
        consent: {
          marketing: true,
          analytics: true,
          ccpaOptOut: false,
          gdprCompliant: true,
          updatedAt: timestamp
        },
        identifiers: [
          ...(suppliedCookie ? [{
            id: `id_c_${Date.now()}`,
            type: 'anonymous_cookie' as const,
            value: suppliedCookie,
            source: eventData.source,
            confidence: 1.0,
            firstSeen: timestamp,
            lastSeen: timestamp,
            isPrimary: !suppliedEmail
          }] : []),
          ...(suppliedEmail ? [{
            id: `id_e_${Date.now()}`,
            type: 'email' as const,
            value: suppliedEmail,
            source: eventData.source,
            confidence: 1.0,
            firstSeen: timestamp,
            lastSeen: timestamp,
            isPrimary: true
          }] : [])
        ],
        identityGraph: {
          nodes: [
            ...(suppliedCookie ? [{
              id: 'n_c1',
              label: suppliedCookie,
              type: 'anonymous_cookie' as const,
              source: eventData.source,
              isPrimary: !suppliedEmail,
              x: 200,
              y: 140
            }] : []),
            ...(suppliedEmail ? [{
              id: 'n_e1',
              label: suppliedEmail,
              type: 'email' as const,
              source: eventData.source,
              isPrimary: true,
              x: 320,
              y: 140
            }] : [])
          ],
          edges: (suppliedCookie && suppliedEmail) ? [{
            id: `e_init_${Date.now()}`,
            source: 'n_c1',
            target: 'n_e1',
            rule: 'Deterministic: Ingestion Identity Link',
            confidence: 1.0,
            timestamp
          }] : []
        },
        traits: eventData.properties,
        segmentIds: [],
        recentEvents: [{
          id: eventId,
          customerId: newCustId,
          name: eventData.name,
          category: eventData.category,
          source: eventData.source,
          timestamp,
          properties: eventData.properties,
          identifiersSupplied: eventData.identifiersSupplied
        }]
      };

      return [newProfile, ...prev];
    });

    // Add to global live feed
    const globalEvent: CustomerEvent = {
      id: eventId,
      customerId: eventData.customerId || 'cust_unassigned',
      name: eventData.name,
      category: eventData.category,
      source: eventData.source,
      timestamp,
      properties: eventData.properties,
      identifiersSupplied: eventData.identifiersSupplied
    };
    setLiveEvents(prev => [globalEvent, ...prev.slice(0, 49)]);
  }, []);

  // Re-evaluate segments whenever customers change
  useEffect(() => {
    setSegments(prev => evaluateSegmentMatches(prev, customers));
  }, [customers, evaluateSegmentMatches]);

  // Create Segment
  const createSegment = useCallback((newSeg: Omit<Segment, 'id' | 'profileCount' | 'matchRatePercent' | 'lastCalculated'>) => {
    const id = `seg_${Date.now()}`;
    const initialSegment: Segment = {
      ...newSeg,
      id,
      profileCount: 0,
      matchRatePercent: 0,
      lastCalculated: new Date().toISOString()
    };
    setSegments(prev => evaluateSegmentMatches([...prev, initialSegment], customers));
  }, [customers, evaluateSegmentMatches]);

  // Update Segment
  const updateSegment = useCallback((id: string, updates: Partial<Segment>) => {
    setSegments(prev => {
      const updated = prev.map(s => s.id === id ? { ...s, ...updates } : s);
      return evaluateSegmentMatches(updated, customers);
    });
  }, [customers, evaluateSegmentMatches]);

  // Delete Segment
  const deleteSegment = useCallback((id: string) => {
    setSegments(prev => prev.filter(s => s.id !== id));
  }, []);

  // Trigger Sync Simulation for a segment or all destinations
  const triggerSync = useCallback(async (segmentId: string, destinationId?: string) => {
    const targetSegment = segments.find(s => s.id === segmentId);
    if (!targetSegment) return;

    const destList = destinationId
      ? destinations.filter(d => d.id === destinationId)
      : destinations.filter(d => targetSegment.syncDestinations.includes(d.id));

    if (destList.length === 0) return;

    // Set segment status to syncing
    setSegments(prev => prev.map(s => s.id === segmentId ? { ...s, status: 'syncing' } : s));

    // Simulate async sync push to APIs
    await new Promise(r => setTimeout(r, 900));

    const newLogs: SyncExecutionLog[] = destList.map(dest => {
      const pushed = Math.max(1, targetSegment.profileCount * 350 + Math.floor(Math.random() * 200));
      const matchRate = +(dest.matchRateBenchmark + (Math.random() * 2 - 1)).toFixed(1);
      const matched = Math.round(pushed * (matchRate / 100));
      const latency = Math.floor(180 + Math.random() * 240);

      return {
        id: `log_${Date.now()}_${dest.id}`,
        destinationId: dest.id,
        destinationName: dest.name,
        segmentId: targetSegment.id,
        segmentName: targetSegment.name,
        timestamp: new Date().toISOString(),
        profilesPushed: pushed,
        profilesMatched: matched,
        matchRate,
        latencyMs: latency,
        status: 'success',
        sampleHashedPayload: dest.hashingAlgorithm === 'SHA-256'
          ? `SHA256(email)=${Math.random().toString(36).substring(2, 12)}... | Count: ${matched}`
          : `Encrypted ID: ${targetSegment.id} | Synced ${matched} users`
      };
    });

    setSyncLogs(prev => [...newLogs, ...prev]);

    // Update destination totals and timestamps
    setDestinations(prev => prev.map(d => {
      const matchingLog = newLogs.find(l => l.destinationId === d.id);
      if (matchingLog) {
        return {
          ...d,
          totalSyncedProfiles: d.totalSyncedProfiles + matchingLog.profilesMatched,
          lastSyncAt: new Date().toISOString(),
          lastSyncStatus: 'success'
        };
      }
      return d;
    }));

    setSegments(prev => prev.map(s => s.id === segmentId ? { ...s, status: 'active' } : s));
  }, [segments, destinations]);

  // Sync All Audiences
  const syncAllAudiences = useCallback(async () => {
    setIsSyncingGlobal(true);
    for (const seg of segments) {
      await triggerSync(seg.id);
    }
    setIsSyncingGlobal(false);
  }, [segments, triggerSync]);

  // Toggle Destination Status
  const toggleDestinationStatus = useCallback((destId: string) => {
    setDestinations(prev => prev.map(d => {
      if (d.id === destId) {
        return {
          ...d,
          status: d.status === 'connected' ? 'paused' : 'connected'
        };
      }
      return d;
    }));
  }, []);

  // Update Destination Frequency
  const updateDestinationFrequency = useCallback((destId: string, freq: Destination['syncFrequency']) => {
    setDestinations(prev => prev.map(d => d.id === destId ? { ...d, syncFrequency: freq } : d));
  }, []);

  // Auto-stream simulator: periodically emits events in the background if enabled
  useEffect(() => {
    if (!isAutoStreaming) return;
    const interval = setInterval(() => {
      const templates: Array<{
        name: string;
        category: CustomerEvent['category'];
        source: CustomerEvent['source'];
        properties: Record<string, any>;
        identifiersSupplied: Record<string, string>;
      }> = [
        {
          name: 'Pageview: Enterprise Pricing',
          category: 'web',
          source: 'Web JS SDK',
          properties: { url: '/pricing/enterprise-quote', dwellSeconds: 45 },
          identifiersSupplied: { cookie: 'nx_anon_7b99c01ff8a', email: 'marcus.vance@vanguardhq.com' }
        },
        {
          name: 'Mobile App Push Notification Engaged',
          category: 'mobile',
          source: 'iOS App',
          properties: { campaign: 'flash_sale_retargeting', deepLink: 'app://cart' },
          identifiersSupplied: { email: 'dev.patel@horizon-ai.io' }
        },
        {
          name: 'Product Added to Cart',
          category: 'ecom',
          source: 'Shopify',
          properties: { product: 'Merino Wool Coat', amount: 320, currency: 'USD' },
          identifiersSupplied: { email: 'priya.sharma@luminafashion.com' }
        },
        {
          name: 'Anonymous Cookie Generated',
          category: 'web',
          source: 'Web JS SDK',
          properties: { ip: '194.28.11.2', referrer: 'google.com/search' },
          identifiersSupplied: { cookie: `nx_anon_${Math.random().toString(36).substring(2, 10)}` }
        }
      ];

      const chosen = templates[Math.floor(Math.random() * templates.length)];
      ingestEvent(chosen);
    }, 6000);

    return () => clearInterval(interval);
  }, [isAutoStreaming, ingestEvent]);

  const toggleAutoStream = useCallback(() => {
    setIsAutoStreaming(prev => !prev);
  }, []);

  return (
    <CDPContext.Provider
      value={{
        currentView,
        setCurrentView,
        customers,
        selectedCustomer,
        selectedCustomerId,
        setSelectedCustomerId,
        segments,
        destinations,
        dataSources,
        syncLogs,
        liveEvents,
        isAutoStreaming,
        toggleAutoStream,
        isSyncingGlobal,
        ingestEvent,
        stitchIdentities,
        createSegment,
        updateSegment,
        deleteSegment,
        triggerSync,
        syncAllAudiences,
        toggleDestinationStatus,
        updateDestinationFrequency
      }}
    >
      {children}
    </CDPContext.Provider>
  );
};

export const useCDP = () => {
  const context = useContext(CDPContext);
  if (!context) {
    throw new Error('useCDP must be used within a CDPProvider');
  }
  return context;
};

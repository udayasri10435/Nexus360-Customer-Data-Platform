export type LifecycleStage = 
  | 'Anonymous'
  | 'Lead'
  | 'Subscriber'
  | 'Free Trial'
  | 'Paying Customer'
  | 'VIP Customer'
  | 'At-Risk'
  | 'Churned';

export type IdentifierType = 
  | 'email'
  | 'phone'
  | 'anonymous_cookie'
  | 'stripe_customer_id'
  | 'crm_lead_id'
  | 'mobile_idfa'
  | 'shopify_customer_id';

export interface ProfileIdentifier {
  id: string;
  type: IdentifierType;
  value: string;
  source: string;
  confidence: number;
  firstSeen: string;
  lastSeen: string;
  isPrimary?: boolean;
}

export interface GraphNode {
  id: string;
  label: string;
  type: IdentifierType;
  source: string;
  isPrimary?: boolean;
  x?: number;
  y?: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  rule: string;
  confidence: number;
  timestamp: string;
}

export interface CustomerEvent {
  id: string;
  customerId: string;
  name: string;
  category: 'web' | 'ecom' | 'crm' | 'billing' | 'mobile' | 'marketing';
  source: 'Web JS SDK' | 'Shopify' | 'Salesforce CRM' | 'Stripe' | 'iOS App' | 'Google Ads' | 'Meta Ads' | 'Zendesk';
  timestamp: string;
  properties: Record<string, any>;
  identifiersSupplied: Record<string, string>;
}

export interface CustomerProfile {
  id: string;
  canonicalId: string;
  name: string;
  primaryEmail: string;
  primaryPhone: string;
  company?: string;
  role?: string;
  avatarInitials: string;
  lifecycleStage: LifecycleStage;
  ltv: number;
  orderCount: number;
  avgOrderValue: number;
  churnRisk: number; // 0 - 100
  npsScore: number;
  rfmScore: {
    recency: number; // 1-5
    frequency: number; // 1-5
    monetary: number; // 1-5
  };
  firstSeenAt: string;
  lastActiveAt: string;
  country: string;
  city: string;
  preferredChannel: 'Email' | 'Paid Social (Meta)' | 'Google Search' | 'SMS' | 'Push Notification';
  consent: {
    marketing: boolean;
    analytics: boolean;
    ccpaOptOut: boolean;
    gdprCompliant: boolean;
    updatedAt: string;
  };
  identifiers: ProfileIdentifier[];
  identityGraph: {
    nodes: GraphNode[];
    edges: GraphEdge[];
  };
  traits: Record<string, any>;
  segmentIds: string[];
  recentEvents: CustomerEvent[];
}

export type OperatorType = 
  | 'equals'
  | 'not_equals'
  | 'greater_than'
  | 'less_than'
  | 'contains'
  | 'performed_event'
  | 'not_performed_event';

export interface SegmentRule {
  id: string;
  field: string;
  operator: OperatorType;
  value: any;
  timeframeDays?: number;
}

export interface SegmentRuleGroup {
  combinator: 'AND' | 'OR';
  rules: SegmentRule[];
}

export interface Segment {
  id: string;
  name: string;
  description: string;
  category: 'Retention' | 'High Value' | 'Acquisition' | 'Winback' | 'Engagement';
  rules: SegmentRuleGroup;
  profileCount: number;
  matchRatePercent: number;
  lastCalculated: string;
  syncDestinations: string[]; // destination IDs
  status: 'active' | 'syncing' | 'paused';
  projectedRoas?: number;
}

export interface Destination {
  id: string;
  name: string;
  category: 'ad_platform' | 'marketing_cloud' | 'crm' | 'warehouse';
  icon: string;
  status: 'connected' | 'syncing' | 'paused';
  syncFrequency: 'realtime' | '15m' | '1h' | '24h';
  hashingAlgorithm: 'SHA-256' | 'Plaintext (Encrypted)';
  matchRateBenchmark: number; // e.g. 81.4%
  activeAudiencesCount: number;
  totalSyncedProfiles: number;
  supportedIdentifiers: string[];
  lastSyncAt: string;
  lastSyncStatus: 'success' | 'warning' | 'in_progress';
}

export interface SyncExecutionLog {
  id: string;
  destinationId: string;
  destinationName: string;
  segmentId: string;
  segmentName: string;
  timestamp: string;
  profilesPushed: number;
  profilesMatched: number;
  matchRate: number;
  latencyMs: number;
  status: 'success' | 'partial' | 'error';
  sampleHashedPayload?: string;
}

export interface DataSource {
  id: string;
  name: string;
  type: 'ecom' | 'client_sdk' | 'mobile_sdk' | 'crm' | 'billing' | 'warehouse';
  categoryName: string;
  status: 'streaming' | 'healthy' | 'idle';
  eventsPerSec: number;
  totalEvents24h: number;
  lastEventReceived: string;
  schemaFieldsCount: number;
}
